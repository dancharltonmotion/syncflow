# Building a self-contained app and DMG

**You almost certainly don't need this.** `Install.command` already gives you a Syncflow app in your Applications folder, and it's the better option for your own machine: it installs in five minutes rather than ten, takes a fraction of the disk space, and never triggers a security warning because it's assembled locally.

This page is for one specific case: **handing Syncflow to people who can't or won't run an installer.** It produces a single `.dmg` with Python, numpy, scipy and ffmpeg all sealed inside — drag to Applications, done, no Homebrew on the recipient's machine at all.

The trade-offs are real. The bundle is a few hundred megabytes rather than tens. Recipients get a Gatekeeper warning on first launch unless you pay for an Apple Developer account and notarize it. And bundling Homebrew's ffmpeg brings GPL obligations with it — see [LICENSE](../LICENSE).

---

## Before you start

You need Homebrew installed. `Install.command` will have done that already; otherwise see [GETTING-STARTED.md](GETTING-STARTED.md). Nothing else is required — the build script fetches the rest itself.

## Build it

Open Terminal and run two lines:

```
cd ~/Downloads/Syncflow
```

```
bash packaging/build_app.sh
```

(Adjust the first line if you unzipped Syncflow somewhere else. Type `cd `, then drag the folder from Finder into Terminal.)

Then leave it alone for five to ten minutes. It will:

1. install `ffmpeg` and `dylibbundler` through Homebrew if they're missing
2. create a throwaway virtualenv inside the project folder, so nothing touches your system Python
3. turn the icon PNG into a proper `.icns`
4. copy ffmpeg **into the app**, along with the several dozen libraries it depends on, so the finished app works on a Mac that has never had Homebrew
5. run PyInstaller to produce `Syncflow.app`
6. ad-hoc code-sign it — not optional on Apple Silicon, which refuses to run unsigned binaries
7. package it into a drag-to-install disk image

When it finishes you'll see:

```
Done.
  App:  /Users/you/Downloads/Syncflow/dist/Syncflow.app
  DMG:  /Users/you/Downloads/Syncflow/dist/Syncflow.dmg  (110M)
```

It's a few hundred megabytes because numpy, scipy, Python and ffmpeg are all inside. That's normal for this kind of app.

## Install it

Open `dist/Syncflow.dmg` and drag Syncflow into Applications, the way you would with anything else.

**On first launch: right-click the app icon and choose Open, then click Open again in the dialog.** Double-clicking it the normal way will give you "Syncflow cannot be opened because it is from an unidentified developer".

That's Gatekeeper, and it's expected. The app is ad-hoc signed, which satisfies Apple Silicon's requirement that binaries be signed at all, but it isn't *notarized* — that needs a paid Apple Developer account ($99/year) and a round trip to Apple's servers. Right-click-Open tells macOS you vouch for it, and you only do it once. Every launch after that is a normal double-click.

---

## Using the app

Launching Syncflow opens a page in your browser. The app itself is the thing serving it — closing the tab quits the app, and there's a Quit button at the bottom too. The **Choose XML…** and **Choose Folder…** buttons open the real macOS file chooser, not a browser upload dialog, so picking a folder of rushes costs nothing.

The page has four parts, top to bottom.

**Footage** — *Choose XML…* for a Final Cut Pro XML exported from Premiere, or *Choose Folder…* to point straight at a card or footage folder with no XML at all. You can also drag an XML onto the app icon in the Dock.

**Save synced sequence to** — fills in automatically next to your footage; change it if you'd rather it went elsewhere.

**Options:**

| Control | What to do with it |
|---|---|
| Editor | Leave on Premiere Pro. |
| Take order | *Chronological* packs takes back to back in recording order. *Real time* spaces them at the actual gaps of the shooting day, which makes a missing take obvious. |
| Matching | *Normal* to start. Switch to *Strict* if you get a wrong match, *Loose* if things fail to sync at all. |
| Audio channels | *Mix* normally. *Channel 1 only* if a recorder has two different mics on left and right, or a stereo pair cancels itself out. |
| Gap between takes | Seconds of space between takes. |
| Drop camera audio… | Removes camera scratch audio wherever a proper recorder covers the same take. Halves your track count. |
| Check for clock drift | Slower. Worth it on takes over ten minutes. |
| Create multicam clips | Final Cut only; ignored for Premiere. |

**Sync** starts it. The progress bar and the Details box show what's happening, and Cancel stops it cleanly at any point.

When it finishes you get a summary — *"6 of 7 files synced into 2 takes"* — and two buttons: **Open Report** and **Show Sequence in Finder**.

Open the report before you import. It's the fastest way to catch a problem: a coloured timeline strip per camera, a table of takes, and every file's confidence score. Green is solid, orange is worth a look, red didn't sync.

Then in Premiere: **File → Import**, pick the XML.

---

## If the build fails

**The app opens a browser tab instead of a window** — That's intended. Tcl/Tk 9.0 aborts during its own start-up on macOS 26, before any application code runs, so the interface is served from the app over a loopback connection instead. It only listens on 127.0.0.1, needs a token generated fresh at each launch, and shuts itself down once you close the tab.

**`command not found: brew`** — The PATH line from setup didn't take. Run this, then retry:

```
eval "$(/opt/homebrew/bin/brew shellenv)"
```

**PyInstaller errors about a missing module** — Add the module name to the `hiddenimports` list in `packaging/Syncflow.spec` and rebuild. This occasionally happens as scipy reorganises its internals between versions.

**The app opens and immediately quits, or no browser tab appears** — Run it from Terminal to see the actual error and the URL it is serving:

```
/Applications/Syncflow.app/Contents/MacOS/Syncflow
```

**`Dest folder does not exist. Create it or pass the appropriate flag`** — This is
dylibbundler needing its `-cd` flag. Fixed in the current `build_app.sh`; if you
have an older copy, change `dylibbundler -of -b` to `dylibbundler -cd -of -b`.

**`dylibbundler missing`** appears as a warning — The app will still build, but it'll depend on Homebrew's ffmpeg being installed and won't work if you pass it to someone else. `brew install dylibbundler` and rebuild to fix.

To rebuild from scratch at any point, delete `dist`, `build` and `.buildenv` in the project folder and run the script again.

---

## Sending it to other people

The app will run on other Apple Silicon Macs, but each person has to do the right-click-Open dance once, and macOS will be increasingly insistent about it over time. If you want it to install cleanly for a team, you need an Apple Developer account and two extra steps in the build: signing with a Developer ID certificate instead of ad-hoc, and submitting the app to Apple for notarization with `notarytool`. That's a change of about five lines in `build_app.sh` once you have the certificate.

Also worth knowing: Homebrew's ffmpeg is built with GPL components, so an app that bundles it inherits GPL obligations if you distribute it publicly. Fine for you and your colleagues; something to look into properly before selling it.
