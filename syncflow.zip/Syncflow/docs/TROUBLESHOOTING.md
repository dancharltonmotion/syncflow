# Troubleshooting

## Installing

**"Install.command cannot be opened because it is from an unidentified developer"**
Right-click the file, choose **Open**, then **Open** again in the dialog. macOS quarantines anything downloaded from the internet. Once is enough.

**"Install.command" is damaged and can't be opened**
Same cause, stricter wording on newer macOS. Open Terminal, paste this, press Return, then try again:

```
xattr -d com.apple.quarantine ~/Downloads/Syncflow/Install.command
```

Adjust the path if you put the folder somewhere other than Downloads.

**Nothing happens when I double-click it**
Your Mac may be set to open `.command` files with a text editor. Right-click → **Open With** → **Terminal**.

**The installer asks for a password and nothing appears as I type**
That's how Unix password prompts work — no dots, no asterisks. Type it and press Return.

**It stopped partway through**
Run it again. It's safe to repeat; it picks up from wherever it got to and overwrites anything half-finished.

**"Could not install Syncflow. Are you online?"**
The install needs internet to fetch numpy and scipy. Check your connection, and if you're on a corporate or campus network, a proxy may be blocking it.

---

## Running

**Nothing opens when I launch Syncflow**
It opens in your browser, so check for a new tab first. If there's genuinely nothing, open Terminal and run this to see the real error:

```
"$HOME/Library/Application Support/Syncflow/venv/bin/python" -m syncflow.webui
```

**"ffmpeg was not found" banner at the top of the window**
Open Terminal, run `brew install ffmpeg`, then quit and reopen Syncflow.

**The browser tab is open but the page never loads**
The app quits itself when the page stops responding for 20 seconds, so if the tab sat idle it may already have exited. Launch Syncflow again.

**Choosing a file does nothing**
The chooser is macOS's own dialog and can open behind the browser window. Check your other windows, or the Dock.

**It's very slow**
Time scales with the number of files, since every pair gets compared. A dozen files is seconds; fifty is minutes. Runs are cached, so changing an option and syncing the same footage again is much faster the second time.

---

## Results

**Every file ends up in its own take, nothing syncs**

Three usual causes, in order of likelihood:

1. The clips genuinely don't overlap in time. Nothing to match.
2. The audio is too quiet or too noisy. The report flags files as *silent*.
3. A recorder's two channels cancel out when mixed. Set **Audio channels** to *Channel 1 only* and try again.

If none of those apply, set **Matching** to *Loose* and check the report carefully.

**One sync is clearly wrong**

Open the report and look at the pairwise table at the bottom — it's sorted worst-residual-first, so the offender is at the top. Then set **Matching** to *Strict* and re-run. Repetitive music, applause and long stretches of identical room tone are what fool audio sync.

**Files show as MISSING in the report**

The paths inside the XML don't match where the media actually lives now. Easiest fix is to skip the XML and point Syncflow at the footage folder directly with *Choose Folder…*.

**Sync is out by a frame or two**

Final Cut Pro XML can only store whole frames, so offsets round to the nearest frame — up to half a frame out, roughly 20 ms at 25 fps. If that matters, switch **Editor** to *Final Cut Pro*, which stores exact fractional times.

**It was in sync at the start of a take and drifted by the end**

That's clock drift — recorders and cameras don't run at exactly the same rate. Tick **Check for clock drift** and re-run; the report will tell you how far off each device is, in parts per million. Around 20 ppm is one frame every five minutes or so. Fixing it means re-rendering the audio at a corrected rate, which Syncflow deliberately doesn't do to your media.

**The takes are in the wrong order**

Ordering uses each file's creation date. If a camera's clock was set wrong, the report shows it, and Syncflow warns when a device's timestamps disagree with the audio by more than two minutes. Sync still works — only the ordering is affected. Switch **Take order** to *Stacked* to ignore dates entirely.

**A camera's audio is in the sequence and I don't want it**

Tick **Drop camera audio where a recorder covers the take**.

---

## Still stuck?

Open the report (the HTML file next to your output) and look at the **Warnings** section at the bottom — it usually names the problem directly.

If you're reporting a problem to someone, the most useful things to send are that report file and the contents of the **Details** box in the app.
