# Getting started, the slow way

**Most people do not need this page.** Double-click `Install.command` and everything below is handled for you.

This is here for two situations: you would rather install things yourself and see what is happening, or the installer failed and you want to work through it a step at a time.

You will be copying and pasting commands into Terminal. A command is one line — paste it, press Return, then wait for the prompt to come back before pasting the next one.

---

## Part 1 — One-time setup

### Step 1. Open Terminal

Press **Cmd + Space**, type `terminal`, press **Return**.

A window opens with a line of text ending in `%`. That `%` is the prompt — it means Terminal is ready for a command. Nothing here can break your Mac; you're only installing software.

### Step 2. Install Homebrew

Homebrew is the standard installer for developer tools on macOS. Paste this whole thing as one line:

```
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

Press Return. Then:

- It will ask you to press **Return** to confirm. Do that.
- It will ask for your **Mac login password**. Type it and press Return. **The characters will not appear as you type** — no dots, no asterisks, nothing. That's normal and deliberate. Just type it and press Return.
- If it says it needs to install the Xcode Command Line Tools, let it. That part is a large download and can take several minutes.

This step takes the longest. When you get the `%` prompt back, it's done.

### Step 3. Tell your Mac where Homebrew lives

On Apple Silicon Macs this step is required — skip it and the next commands will fail with "command not found". Two commands, one at a time:

```
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
```

```
eval "$(/opt/homebrew/bin/brew shellenv)"
```

Neither prints anything. Silence means success.

### Step 4. Install ffmpeg and pipx

ffmpeg is the media engine that reads your video and audio files. pipx installs Syncflow so it works as a normal command.

```
brew install ffmpeg pipx
```

This one takes a few minutes — ffmpeg is a big package with a lot of dependencies. Then:

```
pipx ensurepath
```

**Now quit Terminal completely (Cmd + Q) and reopen it.** That last command changed your settings and they only take effect in a fresh window.

### Step 5. Unzip Syncflow

In Finder, find `syncflow.zip` in your Downloads and **double-click it**. You'll get a folder called `syncflow`.

**Drag that folder to your Home folder.** In Finder's sidebar, Home is the one with a house icon and your username. If you don't see it, press **Cmd + Shift + H**.

You should now have `syncflow` sitting in your Home folder.

### Step 6. Install it

Back in Terminal:

```
cd ~/syncflow
```

`cd` means "change directory" — you've just moved into the folder. Then:

```
pipx install .
```

The dot at the end matters; it means "install what's in this folder". This downloads numpy and scipy and takes a minute or two.

### Step 7. Check it worked

```
syncflow --help
```

If you see a list of options, you're done. If you see `command not found: syncflow`, quit Terminal (Cmd + Q), reopen it, and try again — that fixes it almost every time.

---

## Part 2 — Your first sync, the easy way

Before touching Premiere, prove it works on real footage. Syncflow can read a folder of media directly, no XML needed.

Type this — including the trailing space — but **don't press Return yet**:

```
syncflow 
```

Now **drag your footage folder from Finder into the Terminal window** and let go. Terminal pastes the full path for you. This is the single most useful trick for avoiding typos.

Then type the rest and press Return:

```
 --report --dry-run
```

So the full line reads something like:

```
syncflow /Users/you/Desktop/Shoot --report --dry-run
```

`--dry-run` means analyse everything but write no XML. `--report` writes an HTML page. When it finishes, it prints something like:

```
  6/6 sources synced into 2 take(s); 0 left unsynced
  anchor track: C
  report -> /Users/you/Desktop/Shoot_report.html
```

Open that report file (double-click it in Finder). You'll see a timeline strip with a coloured bar per camera, a table of takes, and every source's confidence score. **Look at this before trusting any sync.** Green rows are solid; orange means low confidence and worth checking; red means unsynced or missing.

If that all looks right, run it again without `--dry-run` to actually get an XML.

---

## Part 3 — The Premiere Pro round trip

### 1. Export from Premiere

In Premiere, click your sequence in the Project panel to select it, then:

**File → Export → Final Cut Pro XML**

Save it somewhere easy to find, like your Desktop, as `rushes.xml`. Premiere will warn you that some effects aren't supported — that's expected and fine, since you're only using this to carry file locations and clip in/out points.

If your footage isn't in a sequence yet, drop it all onto a new sequence first. Order and position don't matter at all — Syncflow ignores them.

### 2. Run Syncflow

Type `syncflow ` (with the space), drag `rushes.xml` from Finder into Terminal, then add the rest:

```
syncflow /Users/you/Desktop/rushes.xml -o /Users/you/Desktop/synced.xml --report --mute-camera-audio
```

`-o` sets the output file. `--mute-camera-audio` drops the camera scratch audio wherever an external recorder covers the same take, which halves your track count. Leave it off if you want camera audio kept.

### 3. Import back into Premiere

**File → Import**, choose `synced.xml`.

Premiere creates a new sequence called *[your sequence name] (synced)*. In it:

- **Each camera has its own permanent track.** V1 is always your main camera, V2 always the second, and so on — they never swap partway down.
- **Video and audio are linked**, so dragging a clip moves both.
- **Each take has a marker** on the timeline showing how many sources it contains and when it was recorded.
- **Clips are colour-labelled by sync quality**: green means confidently synced, orange means low confidence, red means it couldn't be synced. Scan for orange and red before you start cutting.

### 4. Turn it into a multicam sequence (optional)

Select the clips for one take, right-click → **Nest** → or use **Create Multi-Camera Source Sequence** with the synchronise option set to **In Points**. Because Syncflow has already aligned everything, in-point sync is exact and Premiere doesn't need to re-analyse audio.

---

## Options worth knowing

Add these to the end of the command.

| Option | What it does |
|---|---|
| `--report` | Writes the HTML audit page. Use it every time. |
| `--dry-run` | Analyse only, write no XML. |
| `--mute-camera-audio` | Drop camera scratch audio where a recorder covers the take. |
| `--order timestamp` | Space takes at real wall-clock distance instead of packing them together. Makes a missing take obvious. |
| `--gap 5` | Seconds of space between takes. Default is 2. |
| `--channel first` | Use only channel 1. Fixes recorders with two different mics on L and R, or a stereo pair that's out of phase. |
| `--min-confidence 0.4` | Stricter matching. Raise it if you get a wrong sync on repetitive music or long stretches of room tone. |
| `--trim-head 1` | Shave a second off the start of every clip. |
| `--drift` | Check for clock drift between long recordings. Slower, worth it on anything over ten minutes. |

---

## If something goes wrong

**`command not found: syncflow`** — Quit Terminal with Cmd + Q and reopen it. If it persists, run `pipx ensurepath` again, then quit and reopen.

**`command not found: brew`** — Step 3 didn't take. Run both of its commands again, then quit and reopen Terminal.

**`ffmpeg and ffprobe must be on PATH`** — Run `brew install ffmpeg`.

**Some files show as MISSING in the report** — The paths in the XML don't match where the media actually is. Add `--media-root ` followed by the folder holding your footage (drag it in from Finder), and Syncflow will search for the files by name.

**Everything lands in its own take, nothing syncs** — Usually one of three things. The clips genuinely don't overlap in time. Or the audio is too quiet or too noisy to match, which the report will show as "silent". Or the recorder's channels cancel out in the downmix — try `--channel first`.

**A sync looks wrong** — Open the report and find the pair in the bottom table, sorted worst-residual-first. A large residual means that pair disagreed with everything else. Raising `--min-confidence` usually cuts it out.

**Terminal asks for permission to access a folder** — Click OK. macOS asks the first time any program touches Desktop, Documents or an external drive.

---

## Everyday use, once it's set up

Only three lines, ever:

```
cd ~/syncflow
syncflow [drag your XML or folder here] -o ~/Desktop/synced.xml --report
```

Then import `synced.xml` into Premiere. You never need to repeat Part 1.
