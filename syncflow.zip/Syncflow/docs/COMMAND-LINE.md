# Command line

Everything the app does is available as a command, which is what you want for batch jobs, watch folders, or wiring Syncflow into an existing pipeline.

After running `Install.command`, the executable lives inside Syncflow's own environment. Add it to your PATH once:

```bash
echo 'alias syncflow="$HOME/Library/Application Support/Syncflow/venv/bin/syncflow"' >> ~/.zshrc
source ~/.zshrc
```

Or install it into your own environment instead:

```bash
pip install -e /path/to/Syncflow
```

## Basics

```bash
syncflow /Volumes/CARD_A -o synced.xml --report
syncflow rushes.xml -o synced.xml --mute-camera-audio
syncflow rushes.xml --dry-run --report        # analyse, write no XML
syncflow --gui                                # open the app interface
```

Input can be a folder of media, a Final Cut Pro XML, or an FCPXML. Output format follows the input unless you set `-f`.

## Options

```
-o, --output PATH          where to write the sequence
-f, --format {xmeml,fcpxml,auto}

sync
    --min-confidence 0.25  reject matches below this score (0-1)
    --channel {mix,first,left,right}
    --no-refine            skip sub-millisecond refinement (faster)
    --drift                estimate clock drift between long recordings
    --residual-tol 0.08    seconds of disagreement before an edge is flagged

layout
    --order {chronological,timestamp,stack,keep}
    --gap 2.0              seconds between takes
    --anchor NAME          force the reference device
    --mute-camera-audio    drop scratch audio where a recorder covers the take
    --trim-head / --trim-tail SECONDS
    --min-clip SECONDS     drop clips shorter than this
    --fps N                force the output sequence frame rate

output
    --report [PATH]        HTML review report
    --json [PATH]          machine-readable results
    --multicam             FCPXML only: real multicam clips
    --audio-layout {stereo,split}
    --time-precision {frame,sample}   FCPXML only
    --no-markers / --no-labels

misc
    --media-root PATH      folder to search when relinking moved media
    --workers N            parallel analysis threads
    --no-cache             ignore the analysis cache
    --dry-run              analyse and report only
-q, --quiet
```

## Batch a folder of shoot days

```bash
for day in /Volumes/RUSHES/*/; do
    syncflow "$day" -o "$day/synced.xml" --report --mute-camera-audio -q
done
```

## The JSON output

`--json` writes every offset, confidence, residual and timestamp — useful for building your own review UI, or for checking sync in CI.

```json
{
  "anchor": "C",
  "stats": {"sources": 7, "synced": 6, "unsynced": 1, "multi_source_groups": 2},
  "groups": [
    {"index": 0, "timeline_start": 0.0, "span": 120.0, "confidence": 0.57,
     "recorded": "2024-05-17T09:15:00+00:00",
     "sources": ["C0001.mov", "MVI_0011.mov", "ZOOM0001.wav"]}
  ],
  "sources": [
    {"name": "C0001.mov", "device": "C", "offset": 10.0, "confidence": 0.59,
     "drift_ppm": 0.0, "created": "2024-05-17T09:15:10+00:00", "group": 0}
  ],
  "edges": [
    {"a": "C0001.mov", "b": "ZOOM0001.wav", "offset": -10.0,
     "confidence": 0.59, "residual": 0.0, "rejected": false}
  ]
}
```

`residual` is how far each pairwise match ended up from the global solution. Anything above about 20 ms is worth looking at.

## As a library

```python
from syncflow.pipeline import Options, run

result = run(Options(
    input="/Volumes/CARD_A",
    output="synced.xml",
    order="chronological",
    mute_camera_audio=True,
    report="auto",
))

for group in result.project.groups:
    print(group.index, group.start_time, group.source_ids)
```

`run()` takes `log`, `progress` and `cancel` callbacks, which is how both the command line and the app interface drive it.

## Exit codes

```
0    success
1    error (bad input, missing media, unreadable XML)
2    ffmpeg not found
130  cancelled
```

## Other platforms

The engine is pure Python plus ffmpeg, so Linux and Windows work fine from the command line:

```bash
pip install -e /path/to/Syncflow    # needs ffmpeg on PATH
syncflow rushes.xml -o synced.xml --report
```

`syncflow --gui` also works on Linux, using `zenity` for file dialogs if it's installed.
