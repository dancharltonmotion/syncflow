# How Syncflow works

For anyone who wants to know what's happening under the hood, extend it, or check the reasoning before trusting it with a job.

Verified against synthetic multicam footage with known ground truth: offsets recovered to **within 0.02 ms**, takes separated correctly, and zero false matches against unrelated material.

```bash
python3 tests/make_fixtures.py /tmp/shoot     # builds a two-take shoot
python3 tests/test_pipeline.py /tmp/shoot     # asserts the results
```

The app interface and the command line both call `syncflow.pipeline.run`, so they cannot drift apart.

---

## How it works

### 1. Ingest

`formats/xmeml.py` and `formats/fcpxml.py` read the project. Both handle a real timeline, a bare bin of clips, or a project with neither — and if the media has moved since the XML was written, `--media-root` triggers a recursive relink by filename.

Everything is then re-probed from disk with `ffprobe`, because XML durations lie after a relink and the XML never carries the metadata we need for ordering.

The model separates **sources** (unique files on disk) from **clips** (uses of a file on a timeline). Analysis runs once per source no matter how many times it appears, which is what makes re-syncing a project that already has an edit in it cheap.

### 2. Alignment — two stages, because they fail differently

**Coarse.** Each file's audio is decoded to 8 kHz mono, then reduced to a six-band half-wave-rectified spectral flux envelope at ~62 Hz. Onset envelopes discard level, EQ and phase — exactly the things that differ between a camera's on-board mic across the room and a lav on a recorder. Matching then happens on a normalised cross-correlation whose denominator is computed per-lag from the actual overlapping region, so a two-frame overlap at the edge of the search range can't produce a spurious spike.

**Fine.** GCC-PHAT on band-limited raw audio, in a 20-second window chosen by locating the loudest common region, with parabolic interpolation on the correlation peak. This takes the answer from ~16 ms accurate to sub-millisecond.

**Confidence** combines peak height, peak prominence over the rest of the correlation, and how much material actually overlapped. This matters more than raw accuracy: a wrong sync delivered confidently is worse than no sync at all. In testing, true matches scored 0.48–0.64 and unrelated material never cleared 0.25.

### 3. Global solve

Pairwise offsets are never chained. Every pair becomes an edge in a graph, and each connected component is solved as a **weighted least-squares problem** with iterative reweighting:

- over-determined loops average out, so accuracy *improves* as you add cameras
- an edge that disagrees with the consensus loses weight, then gets flagged
- every edge ends up with a residual you can inspect in the report

Connected components are the takes. A file that matches nothing lands in its own group and is placed by timestamp instead of being silently dropped.

### 4. Ordering — the creation-date logic

The anchor is the video device holding the most footage. Takes are then ordered by creation timestamp.

The subtlety worth knowing about: **cameras disagree about what `creation_time` means.** Most stamp the start of the recording; several Canon and AVCHD models stamp the stop; file `mtime` is always the stop. Assume wrong and you reverse the order of an entire shoot day.

Syncflow works it out per device from two independent signals:

1. *Self-consistency* — consecutive clips from one camera can't overlap in real time. Under start-stamping the gap must clear the earlier clip's duration; under end-stamping, the later one's. When the clips are different lengths, only one hypothesis survives.
2. *Agreement with the audio sync* — having already solved the true relative positions, each hypothesis is scored against them, using whichever device has the strongest metadata as reference.

If a device's clock disagrees with the audio by more than two minutes, it's flagged and ordering falls back to the other devices.

Timestamps are read in priority order: QuickTime/EXIF tags, container tags, embedded timecode, filename patterns (`20240517_143022`, `240517-143022`), then mtime as a last resort.

Four layout modes:

| `--order` | Result |
|---|---|
| `chronological` (default) | Takes back to back in date order, `--gap` seconds apart. Compact. |
| `timestamp` | Real wall-clock spacing preserved. The timeline becomes a map of the shooting day — good for spotting a missing take. |
| `stack` | Every take starts at zero, for reviewing one at a time. |
| `keep` | Solver order, untouched. |

### 5. Track layout

One device gets one track for the whole sequence, so V1 is always Camera A and never becomes Camera B halfway down. That consistency is what makes the output usable as a multicam source. Devices are ranked by total footage, so the anchor lands on V1. Overlapping clips from the same device spill onto extra lanes rather than being dropped.

Devices are identified from the filename family (`C0001`/`C0002` → `C`, `ZOOM0001` → `ZOOM`), falling back to reel/model metadata, with resolution and frame rate appended only when two families would otherwise collide. Original track membership is used for one thing only: separating two cameras that share a card naming scheme.

---

## Output

**FCP7 XML** (default) — imports into Premiere Pro, DaVinci Resolve, Media Composer, Vegas and EDIUS. Video and audio clipitems are `<link>`ed so they move together, each take gets a sequence marker, and clips are colour-labelled by sync quality (green synced, orange low confidence, red unsynced) so problems are visible in the bin without opening the report.

**FCPXML 1.10** (`-f fcpxml`) — for Final Cut Pro and Resolve. `--multicam` emits real multicam clips with one angle per device, which is usually what you want for a talking-head shoot. Everything hangs off a full-length gap starting at 1 hour, which is how Final Cut itself writes connected clips and the only always-valid way to place a lane before the first camera clip.

**HTML report** (`--report`) — timeline strip coloured by device with opacity tracking confidence, a take table, a per-source table flagging missing/silent/drifting files, and the pairwise matches sorted worst-residual-first. Ten seconds to audit a sync.

**JSON** (`--json`) — every offset, confidence, residual and timestamp, for scripting or for a GUI to consume.

### One honest limitation

FCP7 XML stores time as integer frames, so sync is quantised to the sequence frame rate — up to half a frame, about 20 ms at 25 fps. Every tool in this category has that constraint. FCPXML stores exact rationals, so `-f fcpxml --time-precision sample` keeps sub-frame accuracy; Resolve honours it, Final Cut still snaps clips to its frame grid.

---

## Options worth knowing

```
--channel first          Stereo pair out of phase, or two different mics on
                         L and R? The downmix cancels itself out. Use ch1.
--min-confidence 0.25    Raise it if you get false matches (repetitive music,
                         long stretches of identical room tone).
--drift                  Estimate clock drift between long recordings.
--mute-camera-audio      Drop scratch audio where a recorder covers the take.
--trim-head/--trim-tail  Shave the frames nobody uses off every clip.
--order timestamp        Lay the day out at real wall-clock spacing.
--anchor "CamA"          Override the reference device.
--dry-run --report       Analyse and audit without writing XML.
```

Decoded audio and feature envelopes are cached by content hash, so a re-run with different layout options is near instant — a full re-sync of the test shoot drops from 1.6 s to 0.6 s. `--no-cache` disables it.

### Clock drift

Consumer recorders routinely run 20–200 ppm off nominal, which is roughly one frame of slip every three to eight minutes. `--drift` correlates at three points across each overlap and fits a line to the residuals. It's reported per source and in the JSON, not corrected — correcting it means resampling the media, which is a decision for you, not the sync tool. It's the usual explanation for "it was in sync at the top and drifted by the end".

---

## Making it an NLE plugin

The CLI is the engine; every integration is a thin shell over it.

- **DaVinci Resolve** — the cleanest target. Resolve ships a Python API and a `Scripts` menu, so a script can export the current timeline's XML, call Syncflow, and import the result without the user touching a file dialog.
- **Premiere Pro** — a UXP (or legacy CEP) panel. The panel triggers a Final Cut XML export, shells out to the binary, and imports the returned XML. This is the workflow Syncaila's users already follow manually.
- **Final Cut Pro** — no plugin API for this, so a droplet or Automator/Shortcuts action over the FCPXML round trip is the practical route.
- **Standalone GUI** — the JSON output is designed for this. A window showing the timeline strip, per-take confidence, and drag-to-nudge correction over `report.json` would cover most of what people actually buy these tools for.

Keep the engine a subprocess in all cases. It means one implementation, and the panel stays a few hundred lines.

---

## Roadmap — features worth adding next

Roughly in order of value per unit of work.

**Timecode-first mode.** When every source carries matching jam-synced timecode, trust it and use audio only to verify, flagging any source whose TC disagrees with the audio by more than a frame. Much faster and catches a mis-jammed box, which is a genuinely expensive mistake to find in the edit.

**Spanned-clip stitching.** Cameras split recordings at the 4 GB FAT32 boundary (`GX010012`/`GX020012`, Sony `C0001M01`). Detect chapters by naming convention plus contiguous timecode, treat them as one virtual source, then emit them back as separate clips. Without this, every long take produces a spurious extra group.

**Progressive matching.** All-pairs is O(n²): 100 files is 4,950 comparisons. Order candidate pairs by timestamp proximity, stop early once a component is well connected, and fall back to exhaustive only for stragglers. On a full shoot day this is the difference between minutes and seconds.

**Drift correction, not just detection.** Once drift is measured, offer to write a resampled proxy or emit a speed adjustment in the XML. Needs care around whether the NLE conforms audio and video the same way.

**Waveform overlays in the report.** Two waveforms drawn on top of each other at the solved offset is the fastest possible way for a human to confirm a match. Cheap to add — the decoded audio is already cached.

**Interactive correction.** A `--fix A.mov=+0.043` flag, or a small GUI, that pins one relationship and re-solves everything else around it. The least-squares solver already supports this: pin the edge at infinite weight.

**Sub-frame audio slip.** For frame-quantised XMEML output, the residual sub-frame error could be pushed into the audio clip's source in-point where the NLE allows it, recovering the ~20 ms lost to quantisation.

**Sync to a pre-edited reference.** Lock one track's existing positions and sync everything else around it, so a rough cut survives the sync pass. Syncaila added this in v3 and it's a common ask.

**AAF and OTIO export.** AAF for Media Composer, OpenTimelineIO as a universal intermediate — OTIO would let one exporter reach several NLEs.

**Per-source channel overrides.** `--channel` is currently global. A recorder with a lav on ch1 and a room mic on ch2 wants ch1; a camera wants the downmix.

**Adaptive confidence.** Learn the threshold from the distribution of scores within a project rather than using a fixed 0.25 — the gap between true and false matches is usually obvious in aggregate but sits at a different absolute level for every shoot.

---

## Layout

```
syncflow/
  model.py           Source / Clip / Edge / SyncGroup, frame-rate handling
  media.py           ffprobe + ffmpeg decode, creation-time extraction, cache
  align.py           onset features, normalised xcorr, GCC-PHAT, drift
  solve.py           pairwise matching, IRLS global solve, take detection
  layout.py          device identity, ordering, track assignment
  formats/xmeml.py   FCP7 XML read + write
  formats/fcpxml.py  FCPXML read + write, multicam
  pipeline.py        the run() both front ends call, with progress + cancel
  report.py          HTML report and JSON export
  cli.py             argument parsing over pipeline.run
  webui.py           local browser interface over pipeline.run
packaging/
  build_app.sh       one command: .app + .dmg, ffmpeg bundled
  Syncflow.spec      PyInstaller bundle definition
  launch.py          app entry point
tests/
  make_fixtures.py   builds a synthetic two-take shoot with ground truth
  test_pipeline.py   asserts accuracy, grouping, ordering, false positives
```

Dependencies: `numpy`, `scipy`, and `ffmpeg`/`ffprobe` on PATH. Nothing else.
The interface adds nothing — it is served from `http.server` in the standard
library. Tk was tried first and abandoned: Tcl/Tk 9.0 aborts during its own
initialisation on macOS 26 (an NSMenuItem assertion inside
`Tk_CreateConsoleWindow`), before any application code runs.

Guides: [GETTING-STARTED.md](GETTING-STARTED.md) to install by hand,
[COMMAND-LINE.md](COMMAND-LINE.md) for scripted use,
[BUILD-STANDALONE-APP.md](BUILD-STANDALONE-APP.md) to package a self-contained
`.app`.

---

Built by Dan Charlton, motion designer, London — [dancharlton.net](https://dancharlton.net).
Contributions and forks welcome; it is MIT licensed.
