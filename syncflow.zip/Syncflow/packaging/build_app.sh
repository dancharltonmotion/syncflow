#!/bin/bash
# Build Syncflow.app and Syncflow.dmg on macOS.
#
#   cd ~/syncflow
#   bash packaging/build_app.sh
#
# Everything it installs goes through Homebrew or into a throwaway virtualenv
# inside this folder. Nothing is installed system-wide by pip.

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$HERE")"
VENV="$ROOT/.buildenv"
VENDOR="$HERE/vendor/bin"
APP="$ROOT/dist/Syncflow.app"
DMG="$ROOT/dist/Syncflow.dmg"

step() { printf "\n\033[1m==> %s\033[0m\n" "$1"; }
warn() { printf "\033[33m    %s\033[0m\n" "$1"; }
die()  { printf "\n\033[31mError: %s\033[0m\n" "$1" >&2; exit 1; }

[ "$(uname)" = "Darwin" ] || die "This script builds a macOS app and must run on a Mac."

# ---------------------------------------------------------------- 1. tools
step "Checking build tools"

if ! command -v brew >/dev/null 2>&1; then
    for p in /opt/homebrew/bin/brew /usr/local/bin/brew; do
        [ -x "$p" ] && eval "$($p shellenv)" && break
    done
fi
command -v brew >/dev/null 2>&1 || die "Homebrew is required. See https://brew.sh"

NEEDED=()
command -v ffmpeg >/dev/null 2>&1 || NEEDED+=(ffmpeg)
command -v dylibbundler >/dev/null 2>&1 || NEEDED+=(dylibbundler)

# No Tk needed: the interface is served over loopback HTTP and opened in the
# browser, which also sidesteps the Tk 9.0 crash on macOS 26.
PYBIN="$(brew --prefix)/bin/python3"
[ -x "$PYBIN" ] || PYBIN="$(command -v python3)"

if [ ${#NEEDED[@]} -gt 0 ]; then
    echo "    Installing: ${NEEDED[*]}"
    brew install "${NEEDED[@]}"
    PYBIN="$(brew --prefix)/bin/python3"
fi

echo "    Python:  $PYBIN"
echo "    ffmpeg:  $(command -v ffmpeg)"

# ------------------------------------------------------------ 2. virtualenv
step "Setting up an isolated build environment"
[ -d "$VENV" ] || "$PYBIN" -m venv "$VENV"
# shellcheck disable=SC1091
source "$VENV/bin/activate"
python -m pip install --quiet --upgrade pip wheel
python -m pip install --quiet pyinstaller pillow
python -m pip install --quiet -e "$ROOT"
echo "    Ready."

# ---------------------------------------------------------------- 3. icon
step "Building the app icon"
if [ ! -f "$HERE/Syncflow.icns" ]; then
    ICONSET="$HERE/Syncflow.iconset"
    rm -rf "$ICONSET"; mkdir -p "$ICONSET"
    SRC="$HERE/icon_1024.png"
    [ -f "$SRC" ] || die "packaging/icon_1024.png is missing."
    for size in 16 32 128 256 512; do
        sips -z $size $size "$SRC" --out "$ICONSET/icon_${size}x${size}.png" >/dev/null
        d=$((size * 2))
        sips -z $d $d "$SRC" --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null
    done
    iconutil -c icns "$ICONSET" -o "$HERE/Syncflow.icns"
    rm -rf "$ICONSET"
fi
echo "    $HERE/Syncflow.icns"

# --------------------------------------------------------------- 4. ffmpeg
step "Bundling ffmpeg into the app"
rm -rf "$HERE/vendor"; mkdir -p "$VENDOR/libs"
if cp "$(command -v ffmpeg)" "$VENDOR/ffmpeg" 2>/dev/null \
   && cp "$(command -v ffprobe)" "$VENDOR/ffprobe" 2>/dev/null; then
    chmod +w "$VENDOR/ffmpeg" "$VENDOR/ffprobe"
    if command -v dylibbundler >/dev/null 2>&1; then
        # Homebrew's ffmpeg links against dozens of dylibs outside the bundle;
        # copy them in and rewrite the load paths so the app runs on a Mac that
        # has never seen Homebrew.
        #   -cd  create the destination directory if it is missing
        #   -of  overwrite files already there (ffprobe shares ffmpeg's libs)
        # Note: -od is NOT used, because it wipes the directory and the second
        # pass would delete the libraries the first pass just installed.
        BUNDLED=1
        for tool in ffmpeg ffprobe; do
            dylibbundler -cd -of -b -x "$VENDOR/$tool" \
                -d "$VENDOR/libs" -p @executable_path/libs >/dev/null 2>&1 \
                || BUNDLED=0
        done
        if [ "$BUNDLED" = "1" ] && [ -d "$VENDOR/libs" ]; then
            echo "    ffmpeg + $(ls "$VENDOR/libs" 2>/dev/null | wc -l | tr -d ' ') libraries bundled."
            # Prove it: no absolute Homebrew paths should remain, or the app
            # will break the moment it lands on someone else's Mac.
            LEAKS=$(otool -L "$VENDOR/ffmpeg" | grep -c -E '/opt/homebrew|/usr/local/Cellar' || true)
            [ "$LEAKS" = "0" ] \
                && echo "    Verified self-contained." \
                || warn "$LEAKS library reference(s) still point outside the app."
            "$VENDOR/ffmpeg" -version >/dev/null 2>&1 \
                || warn "Bundled ffmpeg did not run when tested."
        else
            warn "dylibbundler did not complete; the app will fall back to"
            warn "the system's ffmpeg. Build continues."
        fi
    else
        warn "dylibbundler missing - the app will need Homebrew's ffmpeg present."
    fi
else
    warn "Could not copy ffmpeg. The app will look for it on the system instead."
fi

# ---------------------------------------------------------------- 5. build
step "Building Syncflow.app (this takes a few minutes)"
cd "$ROOT"
rm -rf build dist
pyinstaller --noconfirm --clean --distpath dist --workpath build \
    "$HERE/Syncflow.spec"
[ -d "$APP" ] || die "PyInstaller did not produce $APP"

# ----------------------------------------------------------------- 6. sign
step "Signing"
# Apple Silicon refuses to run unsigned binaries, so an ad-hoc signature is not
# optional. It is not a Developer ID signature: users still get one Gatekeeper
# prompt on first launch, which the README explains how to clear.
codesign --force --deep --sign - "$APP" 2>/dev/null \
    && echo "    Ad-hoc signed." \
    || warn "codesign failed; the app may refuse to launch."

# ------------------------------------------------------------------ 7. dmg
step "Creating the disk image"
STAGE="$ROOT/dist/dmg"
rm -rf "$STAGE"; mkdir -p "$STAGE"
cp -R "$APP" "$STAGE/"
ln -s /Applications "$STAGE/Applications"
rm -f "$DMG"
hdiutil create -volname "Syncflow" -srcfolder "$STAGE" \
    -ov -format UDZO "$DMG" >/dev/null
rm -rf "$STAGE"

SIZE=$(du -h "$DMG" | cut -f1)
printf "\n\033[1;32mDone.\033[0m\n"
printf "  App:  %s\n" "$APP"
printf "  DMG:  %s  (%s)\n\n" "$DMG" "$SIZE"
printf "Open the DMG and drag Syncflow to Applications.\n"
printf "First launch: right-click the app and choose Open, then Open again.\n"
printf "You only need to do that once.\n\n"
