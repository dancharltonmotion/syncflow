"""Entry point for the bundled app.

Starts the local web interface. Deliberately does not import tkinter: Tk 9.0
aborts during its own initialisation on macOS 26, and excluding it also keeps
the bundle smaller.
"""

import multiprocessing
import sys

if __name__ == "__main__":
    multiprocessing.freeze_support()
    from syncflow.webui import main
    sys.exit(main())
