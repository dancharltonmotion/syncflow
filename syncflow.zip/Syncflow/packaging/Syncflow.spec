# PyInstaller spec for Syncflow.app
#
# Built by packaging/build_app.sh - run that rather than invoking this directly,
# because it also fetches ffmpeg and assembles the disk image.

import os

HERE = os.path.abspath(os.path.dirname(SPEC))          # noqa: F821 (PyInstaller)
ROOT = os.path.dirname(HERE)
VERSION = "1.0.0"

# ffmpeg/ffprobe are staged here by build_app.sh. If they are absent the app
# still builds and falls back to whatever is installed on the system.
binaries = []
for tool in ("ffmpeg", "ffprobe"):
    p = os.path.join(HERE, "vendor", "bin", tool)
    if os.path.exists(p):
        binaries.append((p, "bin"))

vendor_libs = os.path.join(HERE, "vendor", "bin", "libs")
if os.path.isdir(vendor_libs):
    for name in os.listdir(vendor_libs):
        binaries.append((os.path.join(vendor_libs, name), "bin/libs"))

a = Analysis(                                          # noqa: F821
    [os.path.join(HERE, "launch.py")],
    pathex=[ROOT],
    binaries=binaries,
    datas=[],
    hiddenimports=[
        "syncflow", "syncflow.webui", "syncflow.pipeline", "syncflow.cli",
        "syncflow.formats.xmeml", "syncflow.formats.fcpxml",
        "scipy._lib.array_api_compat.numpy.fft",
        "scipy.special._special_ufuncs",
    ],
    # tkinter is excluded on purpose: Tk 9.0 aborts on macOS 26 during its own
    # start-up (NSMenuItem assertion in Tk_CreateConsoleWindow). The UI is
    # served over loopback HTTP instead, so Tk is not needed at all.
    excludes=["tkinter", "_tkinter", "matplotlib", "PIL", "pytest", "IPython",
              "pandas", "PyQt5", "PySide6", "notebook", "sphinx"],
    noarchive=False,
)

pyz = PYZ(a.pure)                                      # noqa: F821

exe = EXE(                                             # noqa: F821
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="Syncflow",
    console=False,
    target_arch=None,             # native arch; set "universal2" only if your
                                  # numpy/scipy wheels are universal too
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(                                        # noqa: F821
    exe, a.binaries, a.datas,
    strip=False, upx=False, name="Syncflow",
)

app = BUNDLE(                                          # noqa: F821
    coll,
    name="Syncflow.app",
    icon=os.path.join(HERE, "Syncflow.icns"),
    bundle_identifier="com.syncflow.app",
    version=VERSION,
    info_plist={
        "CFBundleName": "Syncflow",
        "CFBundleDisplayName": "Syncflow",
        "CFBundleShortVersionString": VERSION,
        "CFBundleVersion": VERSION,
        "NSHighResolutionCapable": True,
        "LSMinimumSystemVersion": "11.0",
        "LSApplicationCategoryType": "public.app-category.video",
        "NSHumanReadableCopyright": "",
    },
)
