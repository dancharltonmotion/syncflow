#!/bin/bash
#
#  Removes Syncflow. Double-click this file.
#
#  Leaves Homebrew and ffmpeg alone, since other software on your Mac may be
#  using them. Everything Syncflow itself installed is removed.

cd "$(dirname "$0")" || exit 1

BOLD=$'\033[1m'; GREEN=$'\033[32m'; DIM=$'\033[2m'; OFF=$'\033[0m'
SUPPORT="$HOME/Library/Application Support/Syncflow"
CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/syncflow"

printf "\n${BOLD}Remove Syncflow?${OFF}\n\n"
printf "  This deletes:\n"
printf "    the Syncflow app\n"
printf "    its Python environment (%s)\n" "$SUPPORT"
printf "    its analysis cache\n\n"
printf "  It leaves Homebrew and ffmpeg installed, because other software\n"
printf "  on your Mac may depend on them.\n\n"
printf "  Your footage, XML files and reports are never touched.\n\n"
printf "Continue? [y/N] "
read -r reply
case "$reply" in
    [Yy]*) ;;
    *) printf "\nNothing was removed.\n"; read -r -p "Press Return to close. " _; exit 0 ;;
esac

for app in "/Applications/Syncflow.app" "$HOME/Applications/Syncflow.app"; do
    [ -e "$app" ] && rm -rf "$app" && printf "  removed %s\n" "$app"
done
[ -d "$SUPPORT" ] && rm -rf "$SUPPORT" && printf "  removed %s\n" "$SUPPORT"
[ -d "$CACHE" ] && rm -rf "$CACHE" && printf "  removed the analysis cache\n"

printf "\n${GREEN}${BOLD}Syncflow removed.${OFF}\n"
printf "${DIM}To remove ffmpeg as well:  brew uninstall ffmpeg${OFF}\n\n"
read -r -p "Press Return to close. " _
