#!/bin/bash
#
#  Syncflow installer
#  Double-click this file. Nothing here needs to be typed.
#
#  It installs ffmpeg (via Homebrew), sets up a private Python environment in
#  your Library folder, and creates a Syncflow app you can launch like any
#  other. The app is built on this Mac rather than downloaded, so macOS does
#  not treat it as untrusted software and never shows a security warning.

cd "$(dirname "$0")" || exit 1

BOLD=$'\033[1m'; DIM=$'\033[2m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'
RED=$'\033[31m'; OFF=$'\033[0m'

SUPPORT="$HOME/Library/Application Support/Syncflow"
VENV="$SUPPORT/venv"

step()  { printf "\n${BOLD}%s${OFF}\n" "$1"; }
info()  { printf "   %s\n" "$1"; }
ok()    { printf "   ${GREEN}%s${OFF}\n" "$1"; }
warn()  { printf "   ${YELLOW}%s${OFF}\n" "$1"; }

finish() {
    printf "\n${DIM}You can close this window.${OFF}\n"
    # Keep the window up so the message is readable after a double-click.
    read -r -p "Press Return to close. " _ 2>/dev/null
    exit "${1:-0}"
}

fail() {
    printf "\n${RED}${BOLD}Installation stopped.${OFF}\n"
    printf "${RED}%s${OFF}\n" "$1"
    printf "\nIf you are stuck, send this whole window to whoever gave you Syncflow.\n"
    finish 1
}

clear
cat <<'BANNER'
  ____                  __ _
 / ___| _   _ _ __   __/ _| | _____      __
 \___ \| | | | '_ \ / / |_| |/ _ \ \ /\ / /
  ___) | |_| | | | | (_|  _| | (_) \ V  V /
 |____/ \__, |_| |_|\__|_| |_|\___/ \_/\_/
        |___/   automatic multicam sync

BANNER

printf "This will set up Syncflow on your Mac. It takes about five minutes,\n"
printf "mostly waiting for downloads. You may be asked for your Mac password.\n"

[ "$(uname)" = "Darwin" ] || fail "Syncflow's installer only runs on macOS."

# --------------------------------------------------------------- Homebrew
step "1 of 5  Checking for Homebrew"
if ! command -v brew >/dev/null 2>&1; then
    for p in /opt/homebrew/bin/brew /usr/local/bin/brew; do
        [ -x "$p" ] && eval "$("$p" shellenv)" && break
    done
fi

if ! command -v brew >/dev/null 2>&1; then
    info "Homebrew is not installed. It is the standard installer for"
    info "developer tools on macOS, and Syncflow needs it to fetch ffmpeg."
    printf "\n   Install it now? [Y/n] "
    read -r reply
    case "$reply" in
        [Nn]*) fail "Homebrew is required. See https://brew.sh to install it yourself." ;;
    esac
    info "Your Mac password will be requested. Nothing appears as you type it."
    info "That is normal - type it and press Return."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" \
        || fail "Homebrew installation failed. See https://brew.sh"
    for p in /opt/homebrew/bin/brew /usr/local/bin/brew; do
        [ -x "$p" ] && eval "$("$p" shellenv)" && break
    done
    # Make brew available in future Terminal sessions too.
    if [ -x /opt/homebrew/bin/brew ] && ! grep -q "brew shellenv" "$HOME/.zprofile" 2>/dev/null; then
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
    fi
fi
command -v brew >/dev/null 2>&1 || fail "Homebrew still is not on the PATH."
ok "Homebrew ready."

# ----------------------------------------------------------------- ffmpeg
step "2 of 5  Installing ffmpeg"
if command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1; then
    ok "Already installed."
else
    info "Downloading. This is the longest part."
    brew install ffmpeg || fail "Could not install ffmpeg."
    ok "Installed."
fi

# ----------------------------------------------------------------- Python
step "3 of 5  Preparing Python"
find_python() {
    for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 "$(command -v python3)"; do
        [ -x "$c" ] || continue
        "$c" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' \
            2>/dev/null && { echo "$c"; return 0; }
    done
    return 1
}

PYBIN="$(find_python)" || {
    info "Installing a current Python."
    brew install python@3.13 >/dev/null || fail "Could not install Python."
    hash -r
    PYBIN="$(find_python)" || fail "Python 3.10 or newer is required."
}
ok "Using $("$PYBIN" -V 2>&1)"

# --------------------------------------------------------------- the app
step "4 of 5  Installing Syncflow"
mkdir -p "$SUPPORT" || fail "Could not create $SUPPORT"
rm -rf "$VENV"
"$PYBIN" -m venv "$VENV" || fail "Could not create the Python environment."
"$VENV/bin/python" -m pip install --quiet --upgrade pip wheel \
    || fail "Could not update pip. Are you online?"
info "Fetching numpy and scipy (about 60 MB)."
"$VENV/bin/python" -m pip install --quiet . \
    || fail "Could not install Syncflow. Are you online?"
"$VENV/bin/python" -c "import syncflow.webui" \
    || fail "Syncflow installed but will not load."
ok "Installed to $SUPPORT"

# ------------------------------------------------------------- app bundle
step "5 of 5  Creating the Syncflow app"

APPDIR="/Applications"
if [ ! -w "$APPDIR" ]; then
    APPDIR="$HOME/Applications"
    mkdir -p "$APPDIR"
    warn "No permission for /Applications, using $APPDIR instead."
fi
APP="$APPDIR/Syncflow.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

# The executable is a shell script, not a compiled binary, so it needs no code
# signature, and because we are writing it locally it carries no quarantine
# flag. That is why this never triggers a Gatekeeper warning.
cat > "$APP/Contents/MacOS/Syncflow" <<EOF
#!/bin/bash
export PATH="/opt/homebrew/bin:/usr/local/bin:\$PATH"
exec "$VENV/bin/python" -m syncflow.webui
EOF
chmod +x "$APP/Contents/MacOS/Syncflow"

cat > "$APP/Contents/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
 "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Syncflow</string>
  <key>CFBundleDisplayName</key><string>Syncflow</string>
  <key>CFBundleExecutable</key><string>Syncflow</string>
  <key>CFBundleIdentifier</key><string>net.dancharlton.syncflow</string>
  <key>CFBundleIconFile</key><string>Syncflow</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
EOF

if [ -f packaging/icon_1024.png ] && command -v iconutil >/dev/null 2>&1; then
    SET="$(mktemp -d)/Syncflow.iconset"; mkdir -p "$SET"
    for s in 16 32 128 256 512; do
        sips -z $s $s packaging/icon_1024.png --out "$SET/icon_${s}x${s}.png" >/dev/null 2>&1
        d=$((s * 2))
        sips -z $d $d packaging/icon_1024.png --out "$SET/icon_${s}x${s}@2x.png" >/dev/null 2>&1
    done
    iconutil -c icns "$SET" -o "$APP/Contents/Resources/Syncflow.icns" 2>/dev/null \
        && ok "Icon added."
    rm -rf "$(dirname "$SET")"
fi

# Nudge Finder to notice the new app straight away.
touch "$APP"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister \
    -f "$APP" >/dev/null 2>&1

ok "Syncflow installed to $APPDIR"

printf "\n${GREEN}${BOLD}All done.${OFF}\n\n"
printf "  Open ${BOLD}Syncflow${OFF} from your Applications folder, Launchpad or Spotlight.\n"
printf "  It opens its window in your browser - that is intended.\n\n"
printf "  ${DIM}You can delete this installer folder now. Syncflow does not need it.${OFF}\n"
printf "  ${DIM}To remove Syncflow later, run Uninstall.command from this folder.${OFF}\n"

printf "\n   Open Syncflow now? [Y/n] "
read -r reply
case "$reply" in
    [Nn]*) ;;
    *) open "$APP" ;;
esac

finish 0
