"""End-to-end test against synthetic footage with known ground truth.

    python3 tests/make_fixtures.py /tmp/shoot
    python3 tests/test_pipeline.py /tmp/shoot

Checks that we recover the true offsets, split takes correctly, learn each
camera's timestamp convention, order takes by wall clock, and - the one that
actually matters in production - do NOT match unrelated material.
"""
import datetime
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

SHOOT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/shoot"
FAILED = []


def check(label, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + label + (f"   {detail}" if detail else ""))
    if not cond:
        FAILED.append(label)


def run(*extra):
    out = os.path.join(SHOOT, "_test.json")
    subprocess.run([sys.executable, "-m", "syncflow.cli", SHOOT, "--dry-run",
                    "-q", "--json", out, *extra], cwd=ROOT, check=True)
    with open(out) as fh:
        return json.load(fh)


def main():
    truth = json.load(open(os.path.join(SHOOT, "truth.json")))
    d = run()
    by_name = {s["name"]: s for s in d["sources"]}

    print("\nOffset accuracy (vs ground truth)")
    worst = 0.0
    for g in d["groups"]:
        members = [n for n in g["sources"] if n in truth]
        if not members:
            continue
        base = min(truth[n]["master_in"] for n in members)
        for n in members:
            err = abs(by_name[n]["offset"] - (truth[n]["master_in"] - base))
            worst = max(worst, err)
    check("every source within 5 ms of truth", worst < 0.005, f"worst {worst*1000:.2f} ms")

    print("\nGrouping")
    real_takes = {t["take"] for t in truth.values()}
    got = {}
    for g in d["groups"]:
        takes = {truth[n]["take"] for n in g["sources"] if n in truth}
        if len(takes) == 1:
            got[takes.pop()] = set(g["sources"]) & set(truth)
    check("one group per take, no cross-take contamination", len(got) == len(real_takes),
          f"{len(got)}/{len(real_takes)}")
    for t in real_takes:
        expect = {n for n, v in truth.items() if v["take"] == t}
        check(f"take {t} holds exactly its {len(expect)} sources", got.get(t) == expect)

    print("\nCreation-date handling")
    for n, v in truth.items():
        got_dt = by_name[n]["created"]
        if not got_dt:
            check(f"{n} has a date", False)
            continue
        delta = abs((datetime.datetime.fromisoformat(got_dt)
                     - datetime.datetime.fromisoformat(v["true_start"]).replace(
                         tzinfo=datetime.timezone.utc)).total_seconds())
        check(f"{n} start time recovered ({v['anchor']}-stamped)", delta < 2.0,
              f"{delta:.1f}s off")

    print("\nOrdering")
    dated = [g["recorded"] for g in d["groups"] if g["recorded"]]
    check("takes emitted in wall-clock order", dated == sorted(dated))
    ts = run("--order", "timestamp")
    starts = sorted(g["timeline_start"] for g in ts["groups"])
    check("timestamp mode preserves the real gap between takes",
          len(starts) < 2 or starts[1] > 3000, f"gap {starts[1]-starts[0]:.0f}s"
          if len(starts) > 1 else "")

    print("\nFalse positives")
    unrelated = [n for n in by_name if n not in truth]
    if unrelated:
        bad = [e for e in d["edges"]
               if (e["a"] in unrelated) != (e["b"] in unrelated)]
        check("unrelated material forms no cross edges", not bad, f"{len(bad)} edges")
    else:
        print("  SKIP  no unrelated fixture present")

    print("\nConsistency")
    resid = max((abs(e["residual"]) for e in d["edges"]), default=0.0)
    check("no edge disagrees with the global solution by >20 ms", resid < 0.02,
          f"worst {resid*1000:.1f} ms")
    check("no rejected edges", not any(e["rejected"] for e in d["edges"]))

    print("\n" + ("ALL TESTS PASSED" if not FAILED else f"{len(FAILED)} FAILED: {FAILED}"))
    return 1 if FAILED else 0


if __name__ == "__main__":
    raise SystemExit(main())
