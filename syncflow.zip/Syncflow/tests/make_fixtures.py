"""Build a synthetic multicam shoot with known ground truth.

Two takes, three devices. Each device gets a different EQ, level and noise
floor so the matcher has to work for its answer rather than comparing
identical bytes.
"""
import json
import os
import subprocess
import sys
from datetime import datetime, timedelta

import numpy as np
from scipy.io import wavfile

SR = 48000
OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/shoot"


def room(seconds, seed):
    """Speech-ish: amplitude-modulated bandpassed noise plus sharp transients."""
    rng = np.random.default_rng(seed)
    n = int(seconds * SR)
    x = rng.standard_normal(n) * 0.05
    # syllable-rate envelope
    env = np.abs(np.sin(2 * np.pi * np.cumsum(
        3 + 2 * np.sin(2 * np.pi * 0.11 * np.arange(n) / SR)) / SR))
    x *= (0.15 + env)
    # transients (door slams, claps, consonants) - the things sync latches onto
    for t in rng.uniform(0.5, seconds - 0.5, int(seconds * 1.8)):
        i = int(t * SR)
        L = int(0.04 * SR)
        x[i:i + L] += rng.standard_normal(min(L, n - i)) * np.exp(
            -np.linspace(0, 9, min(L, n - i))) * rng.uniform(0.4, 1.0)
    return (x / (np.abs(x).max() + 1e-9) * 0.7).astype(np.float32)


def run(cmd):
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode != 0:
        raise SystemExit(r.stderr.decode()[-2000:])


def main():
    os.makedirs(OUT, exist_ok=True)
    truth = {}

    # take -> (master duration, base wall clock)
    takes = [(120.0, "2024-05-17T09:15:00Z", 11), (95.0, "2024-05-17T11:42:30Z", 22)]

    # (device, prefix, in-point into master, length, video?, eq filter)
    # device, filename pattern, in-point into master, length, video?, eq,
    # whether the camera stamps creation_time at the start or the stop
    plan = [
        ("CamA", "C000{t}", 10.0, 62.0, True,
         "volume=0.35,highpass=f=180,lowpass=f=6500", "start"),
        ("CamB", "MVI_001{t}", 24.5, 55.0, True,
         "volume=0.9,highpass=f=90,lowpass=f=9000,aecho=0.8:0.5:60:0.25", "end"),
        ("Rec", "ZOOM000{t}", 0.0, 0.0, False,
         "volume=1.0,highpass=f=60", "start"),
    ]

    for ti, (dur, when, seed) in enumerate(takes, 1):
        master = room(dur, seed)
        mpath = os.path.join(OUT, f".master{ti}.wav")
        wavfile.write(mpath, SR, master)

        for device, pat, tin, tlen, is_video, eq, anchor in plan:
            name = pat.format(t=ti)
            length = (tlen * (1.0 if ti == 1 else 0.72)) if tlen else dur
            # Realistic per-file wall clock: take start + this device's in-point,
            # stamped at either the start or the stop of the recording.
            t_start = datetime.fromisoformat(when.replace("Z", "+00:00")) + timedelta(seconds=tin)
            stamp = t_start + timedelta(seconds=length if anchor == "end" else 0)
            stamp_s = stamp.strftime("%Y-%m-%dT%H:%M:%S.000000Z")
            ext = ".mov" if is_video else ".wav"
            path = os.path.join(OUT, name + ext)
            truth[os.path.basename(path)] = {
                "take": ti, "device": device, "master_in": tin, "duration": length,
                "anchor": anchor, "true_start": t_start.isoformat()}

            noise = "anoisesrc=color=brown:amplitude=0.02:d=%.3f" % length
            cmd = ["ffmpeg", "-y", "-v", "error",
                   "-ss", f"{tin}", "-t", f"{length}", "-i", mpath,
                   "-f", "lavfi", "-i", noise]
            if is_video:
                cmd += ["-f", "lavfi", "-i",
                        f"testsrc2=size=1280x720:rate=25:duration={length}"]
                maps = ["-map", "2:v"]
            else:
                maps = []
            cmd += ["-filter_complex",
                    f"[0:a]{eq}[s];[s][1:a]amix=inputs=2:duration=first:weights=1 0.35[a]",
                    "-map", "[a]"] + maps
            if is_video:
                cmd += ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "30",
                        "-pix_fmt", "yuv420p"]
            cmd += ["-c:a", "pcm_s16le" if not is_video else "aac",
                    "-ar", "48000", "-ac", "2",
                    "-metadata", f"creation_time={stamp_s}", path]
            run(cmd)
            # Recorders often carry no container date; their file mtime is the
            # moment recording stopped. Reproduce that so the mtime path is
            # exercised for real.
            end_ts = (t_start + timedelta(seconds=length)).timestamp()
            os.utime(path, (end_ts, end_ts))
            print("  wrote", os.path.basename(path))
        os.remove(mpath)

    with open(os.path.join(OUT, "truth.json"), "w") as fh:
        json.dump(truth, fh, indent=2)
    print("fixtures in", OUT)


if __name__ == "__main__":
    main()
