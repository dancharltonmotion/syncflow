"""One pipeline, two front ends.

Both the command line and the desktop app call :func:`run` here, so there is
exactly one implementation of the actual work and the GUI cannot drift away
from the CLI's behaviour.

``run`` reports progress through callbacks and can be cancelled mid-analysis,
because on a real shoot the matching stage is the slow part and people change
their minds about options after watching it start.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from . import layout, report, solve
from .formats import fcpxml, xmeml
from .media import Cache, have_ffmpeg
from .model import Project, Rate
from .solve import Analyzer

MEDIA_EXT = {".mov", ".mp4", ".m4v", ".mxf", ".avi", ".mkv", ".mts", ".m2ts",
             ".braw", ".r3d", ".insv", ".wav", ".aif", ".aiff", ".flac",
             ".mp3", ".m4a", ".caf", ".ogg", ".wma", ".bwf"}


class Cancelled(Exception):
    """Raised when the caller asked us to stop."""


@dataclass
class Options:
    input: str = ""
    output: Optional[str] = None
    format: str = "auto"                 # auto | xmeml | fcpxml

    # sync
    min_confidence: float = 0.25
    channel: str = "mix"                 # mix | first | left | right
    refine: bool = True
    drift: bool = False
    residual_tol: float = 0.08

    # layout
    order: str = "chronological"         # chronological | timestamp | stack | keep
    gap: float = 2.0
    anchor: Optional[str] = None
    mute_camera_audio: bool = False
    trim_head: float = 0.0
    trim_tail: float = 0.0
    min_clip: float = 0.0
    fps: Optional[float] = None

    # output
    report: Optional[str] = None
    json_out: Optional[str] = None
    multicam: bool = False
    audio_layout: str = "stereo"
    time_precision: str = "frame"
    markers: bool = True
    labels: bool = True

    # misc
    media_roots: list[str] = field(default_factory=list)
    workers: int = 0                     # 0 = auto
    cache: bool = True
    cache_dir: Optional[str] = None
    dry_run: bool = False

    def resolved_workers(self) -> int:
        return self.workers or min(8, os.cpu_count() or 4)


@dataclass
class Result:
    project: Project
    info: dict
    stats: dict
    outputs: dict[str, str] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    elapsed: float = 0.0


Log = Callable[[str], None]
Progress = Callable[[float, str], None]      # fraction 0..1, message
Cancel = Callable[[], bool]


def default_output(input_path: str, fmt: str) -> str:
    ext = ".fcpxml" if fmt == "fcpxml" else ".xml"
    if os.path.isdir(input_path):
        return os.path.join(input_path, "synced" + ext)
    return os.path.splitext(input_path)[0] + "_synced" + ext


def scan_folder(path: str) -> Project:
    """Build a Project straight from a folder of media - no XML required."""
    from .model import Source

    project = Project(source_format="folder")
    project.sequence_name = os.path.basename(os.path.abspath(path)) + " (synced)"
    files = []
    for dirpath, dirs, names in os.walk(path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for n in sorted(names):
            if os.path.splitext(n)[1].lower() in MEDIA_EXT and not n.startswith("."):
                files.append(os.path.join(dirpath, n))
    for i, f in enumerate(files, 1):
        s = Source(id=f"src{i}", path=f, name=os.path.basename(f))
        project.sources[s.id] = s
    return project


def load(input_path: str, media_roots: list[str]) -> Project:
    if os.path.isdir(input_path):
        return scan_folder(input_path)
    if not os.path.exists(input_path):
        raise FileNotFoundError(input_path)
    with open(input_path, "rb") as fh:
        head = fh.read(4096).decode("utf-8", "replace")
    if "<fcpxml" in head:
        return fcpxml.read(input_path, media_roots)
    if "<xmeml" in head:
        return xmeml.read(input_path, media_roots)
    raise ValueError("Unrecognised file. Expected a Final Cut Pro XML "
                     "(.xml), an FCPXML, or a folder of media.")


def probe_all(project: Project, workers: int) -> None:
    """Fill in real durations, stream layout and creation dates from disk."""
    from concurrent.futures import ThreadPoolExecutor

    from .media import probe_source
    from .model import Clip, Source

    def do(s: Source):
        if s.missing or not s.path:
            return
        try:
            fresh = probe_source(s.path, s.id, s.name)
        except Exception as exc:
            project.warn(f"could not read {s.name}: {exc}")
            s.missing = True
            return
        for f in ("duration", "has_video", "has_audio", "width", "height", "par",
                  "audio_channels", "audio_rate", "created_at", "created_at_kind",
                  "created_at_source", "start_timecode", "reel", "missing"):
            setattr(s, f, getattr(fresh, f))
        if fresh.has_video:
            s.rate = fresh.rate

    srcs = list(project.sources.values())
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(do, srcs))

    have = {c.source.id for c in project.clips}
    for s in srcs:
        if s.id not in have and not s.missing and s.duration > 0:
            project.clips.append(Clip(id=f"clip{len(project.clips)+1}", source=s,
                                      name=s.name, src_in=0.0, src_out=s.duration))

    for c in project.clips:
        if c.source.duration > 0:
            c.src_out = min(c.src_out, c.source.duration) or c.source.duration
            if c.src_out <= c.src_in:
                c.src_in, c.src_out = 0.0, c.source.duration

    missing = [s.name for s in srcs if s.missing]
    if missing:
        project.warn(f"{len(missing)} file(s) not found on disk: "
                     f"{', '.join(missing[:6])}{'...' if len(missing) > 6 else ''}")


# --------------------------------------------------------------------------

def run(opts: Options, log: Optional[Log] = None,
        progress: Optional[Progress] = None,
        cancel: Optional[Cancel] = None) -> Result:
    """Run the whole pipeline. Raises Cancelled if the caller bails out."""
    t0 = time.time()
    say = log or (lambda _m: None)
    tick = progress or (lambda _f, _m: None)

    def check():
        if cancel and cancel():
            raise Cancelled()

    if not have_ffmpeg():
        raise RuntimeError(
            "ffmpeg was not found. The app needs it to read media files.")

    tick(0.02, "Reading project")
    project = load(opts.input, opts.media_roots)
    say(f"Loaded {len(project.sources)} source file(s) from "
        f"{os.path.basename(opts.input.rstrip(os.sep))}")
    if not project.sources:
        raise ValueError("No media found. Point this at an XML from your editor, "
                         "or a folder containing video and audio files.")
    check()

    tick(0.06, "Inspecting media")
    probe_all(project, opts.resolved_workers())

    if opts.fps:
        project.rate = Rate.from_fps(opts.fps)
    elif project.source_format == "folder":
        rates = [s.rate for s in project.sources.values() if s.has_video]
        if rates:
            project.rate = max(set(rates), key=rates.count)
        vids = [s for s in project.sources.values() if s.has_video and s.width]
        if vids:
            project.width = max(s.width for s in vids)
            project.height = max(s.height for s in vids)

    rates = {(s.rate.timebase, s.rate.ntsc)
             for s in project.sources.values() if s.has_video}
    if len(rates) > 1:
        project.warn(f"Mixed source frame rates; the sequence is {project.rate} "
                     f"and your editor will conform the rest.")
    check()

    layout.assign_devices(project)
    if opts.anchor:
        for s in project.sources.values():
            if opts.anchor.lower() in s.device.lower():
                s.device = opts.anchor

    devices = sorted({s.device for s in project.sources.values()})
    say(f"Found {len(devices)} device(s): {', '.join(devices)}")

    cache = Cache(opts.cache_dir or Cache().root, enabled=opts.cache)
    an = Analyzer(cache, channel_mode=opts.channel)

    def on_pair(done, total, label):
        tick(0.10 + 0.72 * done / max(total, 1),
             f"Matching audio {done}/{total}")

    tick(0.10, "Analysing audio")
    project.edges = solve.build_edges(
        project, an, min_conf=opts.min_confidence, refine=opts.refine,
        drift=opts.drift, workers=opts.resolved_workers(),
        progress=on_pair, cancel=cancel)
    check()

    tick(0.84, "Solving offsets")
    solve.solve_offsets(project, project.edges, residual_tol=opts.residual_tol)
    an.release_audio()

    anchor = opts.anchor or layout.anchor_device(project)
    layout.order_groups(project, mode=opts.order, gap=opts.gap, anchor=anchor)
    layout.apply_offsets(project)
    layout.trim_handles(project, opts.trim_head, opts.trim_tail)
    dropped = layout.drop_short(project, opts.min_clip)
    if dropped:
        project.warn(f"Dropped {dropped} clip(s) shorter than {opts.min_clip}s")

    info = layout.assign_tracks(project, anchor=anchor)
    if opts.mute_camera_audio:
        n = layout.mute_camera_audio(project)
        say(f"Muted camera audio on {n} clip(s)")

    st = project.stats()
    say(f"{st['synced']}/{st['sources']} sources synced into "
        f"{st['multi_source_groups']} take(s)")
    if st["unsynced"]:
        say(f"{st['unsynced']} source(s) could not be synced and were placed "
            f"by timestamp")

    outputs: dict[str, str] = {}
    fmt = opts.format
    if fmt == "auto":
        fmt = "fcpxml" if project.source_format == "fcpxml" else "xmeml"

    out = opts.output or default_output(opts.input, fmt)
    stem = os.path.splitext(out)[0]

    tick(0.92, "Writing files")
    if opts.report:
        rp = stem + "_report.html" if opts.report == "auto" else opts.report
        with open(rp, "w", encoding="utf-8") as fh:
            fh.write(report.render(project, info))
        outputs["report"] = rp
        say(f"Report: {rp}")

    if opts.json_out:
        jp = stem + "_sync.json" if opts.json_out == "auto" else opts.json_out
        report.write_json(project, info, jp)
        outputs["json"] = jp

    if not opts.dry_run:
        if fmt == "fcpxml":
            fcpxml.write(project, out, multicam=opts.multicam,
                         time_precision=opts.time_precision)
        else:
            if opts.multicam:
                project.warn("Multicam clips are an FCPXML feature; wrote a "
                             "layered sequence instead.")
            xmeml.write(project, out, audio_layout=opts.audio_layout,
                        markers=opts.markers, labels=opts.labels)
        outputs["xml"] = out
        say(f"Sequence: {out}")

    tick(1.0, "Done")
    return Result(project=project, info=info, stats=st, outputs=outputs,
                  warnings=list(project.warnings), elapsed=time.time() - t0)
