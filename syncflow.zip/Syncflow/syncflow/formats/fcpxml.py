"""FCPXML (Final Cut Pro X / DaVinci Resolve) reader and writer.

FCPXML stores time as exact rationals, so unlike XMEML it can carry offsets
finer than one frame. FCP itself still snaps clips to the sequence frame grid,
but Resolve honours the finer values, and either way the rational form means
no rounding is baked in by us.

The writer can emit a plain multi-lane sequence or a real multicam clip
(``multicam=True``), which is usually what you want for a talking-head shoot.
"""

from __future__ import annotations

import os
import re
import uuid
import xml.etree.ElementTree as ET
from collections import defaultdict
from fractions import Fraction
from typing import Optional
from xml.dom import minidom

from ..model import Clip, Project, Rate, Source
from .xmeml import path_to_url, relink, url_to_path

FCPXML_VERSION = "1.10"
_TIME_RE = re.compile(r"^\s*(-?\d+)(?:/(\d+))?s\s*$")


def parse_time(value: Optional[str], default: float = 0.0) -> float:
    if not value:
        return default
    m = _TIME_RE.match(value)
    if not m:
        return default
    num = int(m.group(1))
    den = int(m.group(2)) if m.group(2) else 1
    return num / den if den else default


def fmt_time(seconds: float, timescale: int) -> str:
    n = int(round(seconds * timescale))
    return f"{n}/{timescale}s"


def frame_duration(rate: Rate) -> str:
    return f"{1001 if rate.ntsc else 1}/{rate.timebase * (1000 if rate.ntsc else 1)}s"


# --------------------------------------------------------------------------
# Reader
# --------------------------------------------------------------------------

def read(xml_path: str, media_roots: Optional[list[str]] = None) -> Project:
    tree = ET.parse(xml_path)
    root = tree.getroot()
    if root.tag != "fcpxml":
        raise ValueError(f"{xml_path} is not an FCPXML (root <{root.tag}>)")

    project = Project(source_format="fcpxml")
    roots = list(media_roots or [])
    roots.append(os.path.dirname(os.path.abspath(xml_path)))

    formats: dict[str, Rate] = {}
    for f in root.iter("format"):
        fid = f.get("id")
        fd = parse_time(f.get("frameDuration"), 0.0)
        if fid and fd > 0:
            formats[fid] = Rate.from_fps(1.0 / fd)

    assets: dict[str, Source] = {}
    for a in root.iter("asset"):
        aid = a.get("id")
        if not aid:
            continue
        rep = a.find("media-rep")
        src_url = (rep.get("src") if rep is not None else None) or a.get("src") or ""
        path = url_to_path(src_url)
        name = a.get("name") or os.path.basename(path)
        path, found = relink(path, name, roots)
        s = Source(id=f"src{len(assets)+1}", path=path, name=name)
        s.missing = not found
        s.duration = parse_time(a.get("duration"), 0.0)
        s.has_video = a.get("hasVideo") == "1"
        s.has_audio = a.get("hasAudio") == "1"
        s.audio_channels = int(a.get("audioChannels") or 0)
        try:
            s.audio_rate = int(a.get("audioRate") or 48000)
        except ValueError:
            s.audio_rate = 48000
        s.width = int(a.get("width") or 0)
        s.height = int(a.get("height") or 0)
        if a.get("format") in formats:
            s.rate = formats[a["format"]] if isinstance(a, dict) else formats[a.get("format")]
        s.start_timecode = parse_time(a.get("start"), 0.0) or None
        assets[aid] = s
        project.sources[s.id] = s

    seq = root.find(".//sequence")
    if seq is not None:
        if seq.get("format") in formats:
            project.rate = formats[seq.get("format")]
        proj_el = root.find(".//project")
        if proj_el is not None and proj_el.get("name"):
            project.sequence_name = proj_el.get("name") + " (synced)"

    for el in root.iter():
        if el.tag not in ("asset-clip", "clip", "video", "audio"):
            continue
        ref = el.get("ref")
        if ref not in assets:
            continue
        s = assets[ref]
        start = parse_time(el.get("start"), 0.0)
        dur = parse_time(el.get("duration"), s.duration)
        lane = el.get("lane") or "0"
        project.clips.append(Clip(
            id=f"clip{len(project.clips)+1}", source=s,
            src_in=start, src_out=start + dur,
            name=el.get("name") or s.name,
            orig_track=f"lane{lane}",
        ))

    if not project.clips:
        for s in project.sources.values():
            project.clips.append(Clip(id=f"clip{len(project.clips)+1}", source=s,
                                      name=s.name, src_in=0.0, src_out=s.duration,
                                      orig_track="bin"))
    return project


# --------------------------------------------------------------------------
# Writer
# --------------------------------------------------------------------------

def _sub(parent, tag, **attrs):
    clean = {k: str(v) for k, v in attrs.items() if v is not None}
    return ET.SubElement(parent, tag, clean)


def write(project: Project, out_path: str, *, multicam: bool = False,
          time_precision: str = "frame", event_name: str = "Syncflow") -> str:
    rate = project.rate
    timescale = (rate.timebase * 1000 if rate.ntsc else rate.timebase)
    if time_precision == "sample":
        timescale = project.audio_rate or 48000

    def T(seconds: float) -> str:
        if time_precision == "frame":
            frames = rate.to_frames(seconds)
            unit = 1001 if rate.ntsc else 1
            return f"{frames * unit}/{timescale}s"
        return fmt_time(seconds, timescale)

    root = ET.Element("fcpxml", {"version": FCPXML_VERSION})
    resources = _sub(root, "resources")

    fmt_id = "r1"
    _sub(resources, "format", id=fmt_id,
         name=f"FFVideoFormat{project.height}p{int(rate.fps)}",
         frameDuration=frame_duration(rate),
         width=project.width, height=project.height,
         colorSpace="1-1-1 (Rec. 709)")

    asset_ids: dict[str, str] = {}
    rid = 2
    for s in project.sources.values():
        aid = f"r{rid}"
        rid += 1
        asset_ids[s.id] = aid
        a = _sub(resources, "asset", id=aid, name=s.name,
                 uid=uuid.uuid5(uuid.NAMESPACE_URL, s.path or s.name).hex.upper(),
                 start="0s", duration=T(s.duration),
                 hasVideo="1" if s.has_video else None,
                 hasAudio="1" if s.has_audio else None,
                 audioSources="1" if s.has_audio else None,
                 audioChannels=str(s.audio_channels or 2) if s.has_audio else None,
                 audioRate=str(s.audio_rate) if s.has_audio else None,
                 format=fmt_id if s.has_video else None)
        _sub(a, "media-rep", kind="original-media", src=path_to_url(s.path))

    library = _sub(root, "library")
    event = _sub(library, "event", name=event_name)

    if multicam:
        _write_multicam(event, resources, project, asset_ids, fmt_id, T, rid)
    else:
        _write_spine(event, project, asset_ids, fmt_id, T)

    xml = minidom.parseString(ET.tostring(root, encoding="unicode")).toprettyxml(indent="\t")
    xml = xml.replace('<?xml version="1.0" ?>',
                      '<?xml version="1.0" encoding="UTF-8"?>\n'
                      f'<!DOCTYPE fcpxml>')
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(xml)
    return out_path


def _lane_map(project: Project) -> dict[str, int]:
    """Primary storyline gets lane 0; everything else stacks upward."""
    devices: list[str] = []
    for c in sorted(project.clips, key=lambda c: (c.track_v or 99, c.track_a or 99)):
        if c.source.device not in devices:
            devices.append(c.source.device)
    return {d: i for i, d in enumerate(devices)}


# A connected clip's `offset` is measured in its parent's own time base, not on
# the sequence timeline. Anchoring everything to one full-length gap that starts
# at 1 hour - which is what Final Cut itself writes - gives every lane room to
# sit anywhere, including before the first camera clip, without negative times.
GAP_START = 3600.0


def _write_spine(event, project: Project, asset_ids, fmt_id, T):
    proj = _sub(event, "project", name=project.sequence_name)
    seq = _sub(proj, "sequence", format=fmt_id, duration=T(project.duration),
               tcStart="0s", tcFormat="NDF", audioLayout="stereo", audioRate="48k")
    spine = _sub(seq, "spine")

    gap = _sub(spine, "gap", name="Gap", offset="0s",
               start=T(GAP_START), duration=T(max(project.duration, 1.0)))

    lanes = _lane_map(project)
    for c in sorted(project.clips, key=lambda c: (c.timeline_start,
                                                  lanes.get(c.source.device, 0))):
        lane = lanes.get(c.source.device, 0) + 1
        _sub(gap, "asset-clip", ref=asset_ids[c.source.id], lane=lane,
             offset=T(GAP_START + c.timeline_start),
             name=c.name or c.source.name, start=T(c.src_in),
             duration=T(c.duration),
             audioRole="dialogue" if c.track_a else None,
             format=fmt_id if c.source.has_video else None,
             enabled="1" if c.enabled else "0")

    for g in sorted(project.groups, key=lambda g: g.timeline_start):
        _sub(gap, "marker", start=T(GAP_START + g.timeline_start),
             duration=T(1.0), value=f"Take {g.index + 1}")


def _write_multicam(event, resources, project: Project, asset_ids, fmt_id, T, rid):
    """One multicam clip per sync group - the FCP-native way to cut a take."""
    for g in sorted(project.groups, key=lambda g: g.timeline_start):
        clips = [c for c in project.clips if c.source.group == g.index]
        if not clips:
            continue
        mid = f"r{rid}"
        rid += 1
        mname = f"Take {g.index + 1}"
        media = _sub(resources, "media", id=mid, name=mname,
                     uid=uuid.uuid4().hex.upper())
        mc = _sub(media, "multicam", format=fmt_id, tcStart="0s", tcFormat="NDF")

        by_device: dict[str, list[Clip]] = defaultdict(list)
        for c in clips:
            by_device[c.source.device].append(c)

        angles = []
        base = min(c.timeline_start for c in clips)
        for device, dclips in sorted(by_device.items()):
            angle_id = uuid.uuid4().hex.upper()
            angles.append((angle_id, device))
            ang = _sub(mc, "mc-angle", name=device, angleID=angle_id)
            for c in sorted(dclips, key=lambda c: c.timeline_start):
                _sub(ang, "asset-clip", ref=asset_ids[c.source.id],
                     offset=T(c.timeline_start - base), name=c.name or c.source.name,
                     start=T(c.src_in), duration=T(c.duration),
                     format=fmt_id if c.source.has_video else None,
                     audioRole="dialogue" if c.source.has_audio else None)
        g._angles = angles          # stash for the project spine below
        g._media_id = mid

    proj = _sub(event, "project", name=project.sequence_name)
    seq = _sub(proj, "sequence", format=fmt_id, duration=T(project.duration),
               tcStart="0s", tcFormat="NDF", audioLayout="stereo", audioRate="48k")
    spine = _sub(seq, "spine")
    for g in sorted(project.groups, key=lambda g: g.timeline_start):
        if not getattr(g, "_media_id", None):
            continue
        mcc = _sub(spine, "mc-clip", ref=g._media_id, offset=T(g.timeline_start),
                   name=f"Take {g.index + 1}", start="0s", duration=T(g.span))
        for angle_id, device in g._angles[:1]:
            _sub(mcc, "mc-source", angleID=angle_id, srcEnable="all")
        for angle_id, device in g._angles[1:]:
            _sub(mcc, "mc-source", angleID=angle_id, srcEnable="none")
