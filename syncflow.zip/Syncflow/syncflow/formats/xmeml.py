"""FCP7 XML ("xmeml") reader and writer.

This is the lingua franca: Premiere Pro, DaVinci Resolve, Media Composer,
Vegas and EDIUS all import it. Its one real limitation is that every time
value is an integer frame count, so sync is quantised to the sequence frame
rate (up to +-1/2 frame, ~20 ms at 25 fps). The FCPXML writer avoids that.
"""

from __future__ import annotations

import os
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict
from typing import Optional
from xml.dom import minidom

from ..model import Clip, Project, Rate, Source

# Premiere's colour label names, used to flag sync quality in the bin.
LABEL_SYNCED = "Forest"
LABEL_LOW = "Mango"
LABEL_UNSYNCED = "Rose"


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def _text(el: Optional[ET.Element], tag: str, default: str = "") -> str:
    if el is None:
        return default
    node = el.find(tag)
    return node.text if node is not None and node.text is not None else default


def _int(el: Optional[ET.Element], tag: str, default: int = 0) -> int:
    try:
        return int(float(_text(el, tag, str(default))))
    except (TypeError, ValueError):
        return default


def _rate(el: Optional[ET.Element]) -> Optional[Rate]:
    if el is None:
        return None
    r = el.find("rate")
    if r is None:
        return None
    tb = _int(r, "timebase", 0)
    if not tb:
        return None
    return Rate(tb, _text(r, "ntsc", "FALSE").upper() == "TRUE")


def url_to_path(pathurl: str) -> str:
    if not pathurl:
        return ""
    if not pathurl.startswith("file:"):
        return pathurl
    p = urllib.parse.urlparse(pathurl)
    path = urllib.request.url2pathname(p.path)
    # Windows style: file://localhost/C:/foo -> /C:/foo
    if len(path) > 2 and path[0] in "/\\" and path[2] == ":":
        path = path[1:]
    return path


def path_to_url(path: str) -> str:
    path = os.path.abspath(path)
    quoted = urllib.request.pathname2url(path)
    if not quoted.startswith("/"):
        quoted = "/" + quoted
    return "file://localhost" + quoted


def relink(path: str, name: str, roots: list[str]) -> tuple[str, bool]:
    """Find media that has moved. Returns (path, found)."""
    if path and os.path.exists(path):
        return path, True
    base = os.path.basename(path) or name
    if not base:
        return path, False
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        for dirpath, _dirs, files in os.walk(root):
            if base in files:
                return os.path.join(dirpath, base), True
    return path, False


# --------------------------------------------------------------------------
# Reader
# --------------------------------------------------------------------------

def read(xml_path: str, media_roots: Optional[list[str]] = None) -> Project:
    """Parse an FCP7 XML into a Project. Handles both sequences and loose bin
    clips, so you can throw a whole bin at it without building a timeline."""
    tree = ET.parse(xml_path)
    root = tree.getroot()
    if root.tag != "xmeml":
        raise ValueError(f"{xml_path} is not an FCP7 XML (root <{root.tag}>)")

    project = Project(source_format="xmeml")
    roots = list(media_roots or [])
    roots.append(os.path.dirname(os.path.abspath(xml_path)))

    file_defs: dict[str, ET.Element] = {}
    for f in root.iter("file"):
        fid = f.get("id")
        if fid and f.find("pathurl") is not None:
            file_defs[fid] = f

    by_path: dict[str, Source] = {}

    def source_for(fel: ET.Element) -> Optional[Source]:
        fid = fel.get("id")
        full = file_defs.get(fid, fel)
        pathurl = _text(full, "pathurl")
        name = _text(full, "name") or os.path.basename(url_to_path(pathurl))
        path = url_to_path(pathurl)
        path, found = relink(path, name, roots)
        key = os.path.normcase(os.path.abspath(path)) if path else f"id:{fid}"
        if key in by_path:
            return by_path[key]

        s = Source(id=f"src{len(by_path)+1}", path=path, name=name)
        s.missing = not found
        r = _rate(full)
        if r:
            s.rate = r
        dur_f = _int(full, "duration", 0)
        if dur_f:
            s.duration = s.rate.to_seconds(dur_f)
        media = full.find("media")
        if media is not None:
            v = media.find("video")
            a = media.find("audio")
            s.has_video = v is not None
            s.has_audio = a is not None
            sc = v.find("samplecharacteristics") if v is not None else None
            if sc is not None:
                s.width = _int(sc, "width", 0)
                s.height = _int(sc, "height", 0)
            if a is not None:
                s.audio_channels = _int(a, "channelcount", 2)
        tc = full.find("timecode")
        if tc is not None:
            fr = _int(tc, "frame", -1)
            if fr >= 0:
                s.start_timecode = s.rate.to_seconds(fr)
        by_path[key] = s
        project.sources[s.id] = s
        return s

    def add_clipitem(ci: ET.Element, track_name: str, seq_rate: Rate) -> None:
        fel = ci.find("file")
        if fel is None:
            return
        s = source_for(fel)
        if s is None:
            return
        crate = _rate(ci) or s.rate
        in_f = _int(ci, "in", 0)
        out_f = _int(ci, "out", 0)
        if out_f <= in_f:
            dur = _int(ci, "duration", 0)
            out_f = in_f + dur if dur else in_f
        clip = Clip(
            id=ci.get("id") or f"clip{len(project.clips)+1}",
            source=s,
            src_in=max(0.0, crate.to_seconds(in_f)),
            src_out=max(0.0, crate.to_seconds(out_f)),
            name=_text(ci, "name") or s.name,
            orig_track=track_name,
            enabled=_text(ci, "enabled", "TRUE").upper() != "FALSE",
        )
        st = ci.find("sourcetrack")
        mediatype = _text(st, "mediatype", "video") if st is not None else "video"
        # Premiere writes one clipitem per media type; keep only the video one
        # for A/V files so we do not double-count a clip.
        if mediatype == "audio" and s.has_video:
            return
        project.clips.append(clip)

    seqs = root.findall(".//sequence")
    if seqs:
        seq = seqs[0]
        if len(seqs) > 1:
            project.warn(f"{len(seqs)} sequences found; using '{_text(seq, 'name')}'")
        project.sequence_name = _text(seq, "name", "Sequence") + " (synced)"
        sr = _rate(seq)
        if sr:
            project.rate = sr
        media = seq.find("media")
        if media is not None:
            vfmt = media.find("video/format/samplecharacteristics")
            if vfmt is not None:
                project.width = _int(vfmt, "width", 1920) or 1920
                project.height = _int(vfmt, "height", 1080) or 1080
            afmt = media.find("audio/format/samplecharacteristics")
            if afmt is not None:
                project.audio_rate = _int(afmt, "samplerate", 48000) or 48000
            for kind in ("video", "audio"):
                node = media.find(kind)
                if node is None:
                    continue
                for ti, track in enumerate(node.findall("track"), start=1):
                    tname = track.get("id") or f"{kind[0].upper()}{ti}"
                    for ci in track.findall("clipitem"):
                        add_clipitem(ci, tname, project.rate)

    if not project.clips:
        # No sequence (or an empty one): treat every bin clip as material.
        for cl in root.iter("clip"):
            fel = cl.find("file") or cl.find(".//file")
            if fel is None:
                continue
            s = source_for(fel)
            if s is None:
                continue
            crate = _rate(cl) or s.rate
            in_f = _int(cl, "in", 0)
            out_f = _int(cl, "out", 0)
            if out_f <= in_f:
                out_f = in_f + _int(cl, "duration", 0)
            project.clips.append(Clip(
                id=cl.get("id") or f"clip{len(project.clips)+1}",
                source=s, name=_text(cl, "name") or s.name,
                src_in=crate.to_seconds(in_f),
                src_out=crate.to_seconds(out_f) if out_f > in_f else s.duration,
                orig_track="bin",
            ))

    if not project.clips:
        # Last resort: every file reference becomes a whole-file clip.
        for fel in file_defs.values():
            s = source_for(fel)
            if s is None:
                continue
            project.clips.append(Clip(id=f"clip{len(project.clips)+1}", source=s,
                                      name=s.name, src_in=0.0, src_out=s.duration,
                                      orig_track="bin"))
    return project


# --------------------------------------------------------------------------
# Writer
# --------------------------------------------------------------------------

def _sub(parent: ET.Element, tag: str, text=None, **attrs) -> ET.Element:
    el = ET.SubElement(parent, tag, {k: str(v) for k, v in attrs.items()})
    if text is not None:
        el.text = str(text)
    return el


def _rate_el(parent: ET.Element, rate: Rate) -> None:
    r = _sub(parent, "rate")
    _sub(r, "timebase", rate.timebase)
    _sub(r, "ntsc", "TRUE" if rate.ntsc else "FALSE")


def _file_el(parent: ET.Element, src: Source, emitted: set[str]) -> ET.Element:
    fid = f"file-{src.id}"
    f = _sub(parent, "file", id=fid)
    if fid in emitted:
        return f                      # subsequent references are id-only
    emitted.add(fid)
    _sub(f, "name", src.name)
    _sub(f, "pathurl", path_to_url(src.path))
    _rate_el(f, src.rate)
    _sub(f, "duration", src.rate.to_frames(src.duration))
    tc = _sub(f, "timecode")
    _rate_el(tc, src.rate)
    start_tc = src.start_timecode or 0.0
    _sub(tc, "frame", src.rate.to_frames(start_tc))
    _sub(tc, "displayformat", "NDF")
    media = _sub(f, "media")
    if src.has_video:
        v = _sub(media, "video")
        _sub(v, "duration", src.rate.to_frames(src.duration))
        sc = _sub(v, "samplecharacteristics")
        _rate_el(sc, src.rate)
        _sub(sc, "width", src.width or 1920)
        _sub(sc, "height", src.height or 1080)
        _sub(sc, "anamorphic", "FALSE")
        _sub(sc, "pixelaspectratio", "square")
        _sub(sc, "fielddominance", "none")
    if src.has_audio:
        a = _sub(media, "audio")
        _sub(a, "channelcount", max(1, src.audio_channels or 2))
        sc = _sub(a, "samplecharacteristics")
        _sub(sc, "depth", 16)
        _sub(sc, "samplerate", src.audio_rate or 48000)
    return f


def write(project: Project, out_path: str, *, audio_layout: str = "stereo",
          markers: bool = True, labels: bool = True,
          min_confidence: float = 0.35) -> str:
    """Serialise a solved Project to FCP7 XML."""
    rate = project.rate
    fps = rate.fps

    root = ET.Element("xmeml", {"version": "5"})
    seq = _sub(root, "sequence", id="syncflow-seq")
    _sub(seq, "uuid", "00000000-0000-0000-0000-000000000001")
    _sub(seq, "name", project.sequence_name)
    total_f = max(1, rate.to_frames(project.duration))
    _sub(seq, "duration", total_f)
    _rate_el(seq, rate)
    tc = _sub(seq, "timecode")
    _rate_el(tc, rate)
    _sub(tc, "string", "00:00:00:00")
    _sub(tc, "frame", 0)
    _sub(tc, "displayformat", "NDF")
    _sub(seq, "in", -1)
    _sub(seq, "out", -1)

    media = _sub(seq, "media")

    v_clips: dict[int, list[Clip]] = defaultdict(list)
    a_clips: dict[int, list[Clip]] = defaultdict(list)
    for c in project.clips:
        if c.track_v:
            v_clips[c.track_v].append(c)
        if c.track_a:
            a_clips[c.track_a].append(c)

    emitted: set[str] = set()
    # linkgroup -> list of (clipid, mediatype, trackindex, clipindex)
    links: dict[str, list[tuple[str, str, int, int]]] = defaultdict(list)
    clip_index: dict[str, int] = {}

    # ---- video ------------------------------------------------------
    video = _sub(media, "video")
    fmt = _sub(video, "format")
    sc = _sub(fmt, "samplecharacteristics")
    _rate_el(sc, rate)
    _sub(sc, "width", project.width)
    _sub(sc, "height", project.height)
    _sub(sc, "anamorphic", "FALSE")
    _sub(sc, "pixelaspectratio", "square")
    _sub(sc, "fielddominance", "none")

    n_v = max(v_clips.keys(), default=0)
    for ti in range(1, n_v + 1):
        track = _sub(video, "track")
        for i, c in enumerate(sorted(v_clips[ti], key=lambda c: c.timeline_start), 1):
            cid = f"cv-{c.id}"
            clip_index[cid] = i
            links[c.id].append((cid, "video", ti, i))
            _clipitem(track, c, cid, rate, project, emitted, "video", 1,
                      labels, min_confidence)
        _sub(track, "enabled", "TRUE")
        _sub(track, "locked", "FALSE")

    # ---- audio ------------------------------------------------------
    audio = _sub(media, "audio")
    _sub(audio, "numOutputChannels", 2)
    afmt = _sub(audio, "format")
    asc = _sub(afmt, "samplecharacteristics")
    _sub(asc, "depth", 16)
    _sub(asc, "samplerate", project.audio_rate)
    outputs = _sub(audio, "outputs")
    grp = _sub(outputs, "group")
    _sub(grp, "index", 1)
    _sub(grp, "numchannels", 2)
    _sub(grp, "downmix", 0)
    for ch in (1, 2):
        c_el = _sub(grp, "channel")
        _sub(c_el, "index", ch)

    split = audio_layout == "split"
    n_a = max(a_clips.keys(), default=0)
    lanes = n_a * 2 if split else n_a
    for lane in range(1, lanes + 1):
        track = _sub(audio, "track")
        base = ((lane - 1) // 2 + 1) if split else lane
        chan = ((lane - 1) % 2 + 1) if split else 1
        for i, c in enumerate(sorted(a_clips[base], key=lambda c: c.timeline_start), 1):
            if split and chan > max(1, c.source.audio_channels):
                continue
            cid = f"ca{chan}-{c.id}" if split else f"ca-{c.id}"
            clip_index[cid] = i
            links[c.id].append((cid, "audio", lane, i))
            _clipitem(track, c, cid, rate, project, emitted, "audio", chan,
                      labels, min_confidence)
        _sub(track, "enabled", "TRUE")
        _sub(track, "locked", "FALSE")
        _sub(track, "outputchannelindex", 1 if not split else chan)

    # ---- link video and audio so they move together -----------------
    id_to_el = {el.get("id"): el for el in seq.iter("clipitem")}
    for members in links.values():
        if len(members) < 2:
            continue
        for cid, _mt, _tr, _ci in members:
            el = id_to_el.get(cid)
            if el is None:
                continue
            for m_cid, m_mt, m_tr, m_ci in members:
                lk = _sub(el, "link")
                _sub(lk, "linkclipref", m_cid)
                _sub(lk, "mediatype", m_mt)
                _sub(lk, "trackindex", m_tr)
                _sub(lk, "clipindex", m_ci)

    # ---- one marker per take ----------------------------------------
    if markers:
        for g in sorted(project.groups, key=lambda g: g.timeline_start):
            names = {project.sources[n].device for n in g.source_ids}
            mk = _sub(seq, "marker")
            when = g.start_time.strftime("%H:%M:%S") if g.start_time else "no date"
            _sub(mk, "name", f"Take {g.index + 1} - {len(g.source_ids)} src - {when}")
            _sub(mk, "comment", ", ".join(sorted(names))[:200])
            _sub(mk, "in", rate.to_frames(g.timeline_start))
            _sub(mk, "out", -1)

    xml = minidom.parseString(ET.tostring(root, encoding="unicode")).toprettyxml(indent="\t")
    xml = xml.replace('<?xml version="1.0" ?>',
                      '<?xml version="1.0" encoding="UTF-8"?>\n'
                      '<!DOCTYPE xmeml>')
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(xml)
    return out_path


def _clipitem(track: ET.Element, c: Clip, cid: str, rate: Rate, project: Project,
              emitted: set[str], mediatype: str, chan: int,
              labels: bool, min_confidence: float) -> None:
    src = c.source
    srate = src.rate if src.has_video else rate

    start_f = max(0, rate.to_frames(c.timeline_start))
    n_seq = max(1, rate.to_frames(c.duration))
    end_f = start_f + n_seq
    in_f = max(0, srate.to_frames(c.src_in))
    out_f = in_f + max(1, int(round(n_seq * srate.fps / rate.fps)))

    ci = _sub(track, "clipitem", id=cid)
    _sub(ci, "masterclipid", f"master-{src.id}")
    _sub(ci, "name", c.name or src.name)
    _sub(ci, "enabled", "TRUE" if c.enabled else "FALSE")
    _sub(ci, "duration", srate.to_frames(src.duration))
    _rate_el(ci, srate)
    _sub(ci, "start", start_f)
    _sub(ci, "end", end_f)
    _sub(ci, "in", in_f)
    _sub(ci, "out", out_f)
    _file_el(ci, src, emitted)
    st = _sub(ci, "sourcetrack")
    _sub(st, "mediatype", mediatype)
    _sub(st, "trackindex", chan)
    if labels:
        lab = _sub(ci, "labels")
        if src.group is None or src.offset is None:
            _sub(lab, "label2", LABEL_UNSYNCED)
        elif src.confidence >= min_confidence:
            _sub(lab, "label2", LABEL_SYNCED)
        else:
            _sub(lab, "label2", LABEL_LOW)
    note = (f"syncflow: group {src.group} conf {src.confidence:.2f}"
            f"{f' drift {src.drift_ppm:+.0f}ppm' if abs(src.drift_ppm) > 5 else ''}")
    _sub(ci, "comments").text = None
    cm = ci.find("comments")
    _sub(cm, "mastercomment1", note)
