"""Local web interface.

Replaces the Tkinter front end. Tk 9.0 aborts during its own start-up on
macOS 26 while building the default menu bar, before any application code
runs, and there is no workaround available from Python's side. This serves the
same interface over a loopback HTTP server instead: no Tk, no native toolkit,
nothing to go stale when the OS changes.

File pickers still need to return a real filesystem path - a browser only ever
hands over file contents, which is useless for a folder of 40 GB rushes - so
the server shells out to the OS's own dialog (``osascript`` on macOS). The
picker is native even though the window is a browser tab.

The server binds to 127.0.0.1 on a random port, requires a token generated at
launch, and quits on its own once the page stops sending heartbeats.
"""

from __future__ import annotations

import json
import os
import platform
import queue
import secrets
import shutil
import subprocess
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Optional

from .media import have_ffmpeg
from .model import fmt_tc
from .pipeline import Cancelled, Options, default_output, run

IS_MAC = platform.system() == "Darwin"
HEARTBEAT_TIMEOUT = 20.0        # seconds without a ping before we shut down


# --------------------------------------------------------------------------
# Native file pickers
# --------------------------------------------------------------------------

def pick_path(kind: str) -> str:
    """Open the operating system's own file/folder chooser."""
    if IS_MAC:
        if kind == "folder":
            script = 'POSIX path of (choose folder with prompt "Choose a folder of footage")'
        else:
            script = ('POSIX path of (choose file with prompt "Choose an XML '
                      'exported from your editor" of type {"xml", "fcpxml", "public.xml"})')
        try:
            out = subprocess.run(["osascript", "-e", script],
                                 capture_output=True, text=True, timeout=300)
            return out.stdout.strip() if out.returncode == 0 else ""
        except Exception:
            return ""

    if shutil.which("zenity"):
        cmd = ["zenity", "--file-selection"]
        if kind == "folder":
            cmd.append("--directory")
        out = subprocess.run(cmd, capture_output=True, text=True)
        return out.stdout.strip() if out.returncode == 0 else ""
    return ""


def reveal(path: str) -> None:
    if not path or not os.path.exists(path):
        return
    if IS_MAC:
        subprocess.run(["open", "-R", path])
    elif platform.system() == "Windows":
        subprocess.run(["explorer", "/select,", os.path.normpath(path)])
    elif shutil.which("xdg-open"):
        subprocess.run(["xdg-open", os.path.dirname(path)])


def open_file(path: str) -> None:
    if not path or not os.path.exists(path):
        return
    if IS_MAC:
        subprocess.run(["open", path])
    elif platform.system() == "Windows":
        os.startfile(path)                      # type: ignore[attr-defined]
    elif shutil.which("xdg-open"):
        subprocess.run(["xdg-open", path])


# --------------------------------------------------------------------------
# Job state
# --------------------------------------------------------------------------

class Job:
    """Whatever the UI needs to know, guarded by a lock."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.running = False
        self.progress = 0.0
        self.message = ""
        self.log: list[str] = []
        self.summary: Optional[dict] = None
        self.error: Optional[str] = None
        self.outputs: dict[str, str] = {}
        self.cancel = threading.Event()
        self.thread: Optional[threading.Thread] = None

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "running": self.running,
                "progress": self.progress,
                "message": self.message,
                "log": list(self.log),
                "summary": self.summary,
                "error": self.error,
                "outputs": {k: os.path.basename(v) for k, v in self.outputs.items()},
            }

    def start(self, opts: Options) -> None:
        with self.lock:
            if self.running:
                return
            self.running = True
            self.progress = 0.0
            self.message = "Starting"
            self.log = []
            self.summary = None
            self.error = None
            self.outputs = {}
            self.cancel.clear()

        def on_log(m: str) -> None:
            with self.lock:
                self.log.append(m)

        def on_progress(f: float, m: str) -> None:
            with self.lock:
                self.progress, self.message = f, m

        def work() -> None:
            try:
                res = run(opts, log=on_log, progress=on_progress,
                          cancel=self.cancel.is_set)
                with self.lock:
                    self.outputs = dict(res.outputs)
                    self.summary = {
                        "sources": res.stats["sources"],
                        "synced": res.stats["synced"],
                        "unsynced": res.stats["unsynced"],
                        "takes": res.stats["multi_source_groups"],
                        "duration": fmt_tc(res.project.duration, res.project.rate),
                        "anchor": res.info.get("anchor", ""),
                        "elapsed": round(res.elapsed, 1),
                        "warnings": res.warnings,
                    }
                    self.message = "Done"
                    self.progress = 1.0
            except Cancelled:
                with self.lock:
                    self.message = "Cancelled"
            except Exception as exc:
                with self.lock:
                    self.error = str(exc)
                    self.message = "Failed"
            finally:
                with self.lock:
                    self.running = False

        self.thread = threading.Thread(target=work, daemon=True)
        self.thread.start()


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------

class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, addr, handler, token: str):
        super().__init__(addr, handler)
        self.token = token
        self.job = Job()
        self.last_ping = time.time()
        self.should_quit = threading.Event()


class Handler(BaseHTTPRequestHandler):
    server: Server                                   # type: ignore[assignment]

    def log_message(self, *_args) -> None:           # keep the console quiet
        pass

    # -- helpers ---------------------------------------------------------

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj: Any, code: int = 200) -> None:
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json")

    def _authorised(self) -> bool:
        return self.headers.get("X-Syncflow-Token") == self.server.token

    def _body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    # -- routes ----------------------------------------------------------

    def do_GET(self) -> None:
        path = self.path.split("?")[0]
        if path == "/":
            html = PAGE.replace("__TOKEN__", self.server.token)
            self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
            return
        if path == "/api/state":
            if not self._authorised():
                self._json({"error": "unauthorised"}, 403)
                return
            self.server.last_ping = time.time()
            state = self.server.job.snapshot()
            state["ffmpeg"] = have_ffmpeg()
            self._json(state)
            return
        self._send(404, b"not found", "text/plain")

    def do_POST(self) -> None:
        if not self._authorised():
            self._json({"error": "unauthorised"}, 403)
            return
        path = self.path.split("?")[0]
        body = self._body()
        job = self.server.job

        if path == "/api/pick":
            p = pick_path(body.get("kind", "file"))
            out = default_output(p, body.get("format", "xmeml")) if p else ""
            self._json({"path": p, "output": out})

        elif path == "/api/default-output":
            src = body.get("path", "")
            self._json({"output": default_output(src, body.get("format", "xmeml"))
                        if src else ""})

        elif path == "/api/start":
            if not body.get("input"):
                self._json({"error": "Choose footage first."}, 400)
                return
            opts = Options(
                input=body["input"],
                output=body.get("output") or None,
                format=body.get("format", "xmeml"),
                order=body.get("order", "chronological"),
                min_confidence=float(body.get("min_confidence", 0.25)),
                channel=body.get("channel", "mix"),
                gap=float(body.get("gap", 2.0)),
                mute_camera_audio=bool(body.get("mute_camera_audio")),
                drift=bool(body.get("drift")),
                multicam=bool(body.get("multicam")),
                trim_head=float(body.get("trim_head", 0.0)),
                report="auto", json_out="auto",
            )
            job.start(opts)
            self._json({"ok": True})

        elif path == "/api/cancel":
            job.cancel.set()
            self._json({"ok": True})

        elif path == "/api/open":
            which = body.get("which", "report")
            with job.lock:
                target = job.outputs.get("xml" if which == "reveal" else which, "")
            (reveal if which == "reveal" else open_file)(target)
            self._json({"ok": bool(target)})

        elif path == "/api/quit":
            self.server.should_quit.set()
            self._json({"ok": True})

        else:
            self._json({"error": "not found"}, 404)


# --------------------------------------------------------------------------

PAGE = r"""<!doctype html>
<html><head><meta charset="utf-8"><title>Syncflow</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:#0d1117;color:#e6edf3;font:14px/1.55 ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.wrap{max-width:760px;margin:0 auto;padding:32px 28px 64px}
h1{font-size:22px;margin:0 0 4px;letter-spacing:-.2px}
.sub{color:#8b949e;margin:0 0 26px}
.card{background:#161b22;border:1px solid #30363d;border-radius:10px;padding:16px 18px;margin-bottom:14px}
.card h2{font-size:11px;letter-spacing:.09em;text-transform:uppercase;color:#8b949e;margin:0 0 12px;font-weight:600}
.pathbox{background:#0d1117;border:1px solid #21262d;border-radius:7px;padding:10px 12px;font-family:ui-monospace,Menlo,monospace;font-size:12.5px;color:#8b949e;word-break:break-all;min-height:40px;display:flex;align-items:center}
.pathbox.set{color:#e6edf3}
.row{display:flex;gap:9px;flex-wrap:wrap;margin-top:11px}
button{font:inherit;font-size:13px;padding:8px 15px;border-radius:7px;border:1px solid #30363d;background:#21262d;color:#e6edf3;cursor:pointer;transition:.12s}
button:hover:not(:disabled){background:#30363d;border-color:#484f58}
button:disabled{opacity:.4;cursor:default}
button.primary{background:#238636;border-color:#2ea043;font-weight:600;padding:10px 26px;font-size:14px}
button.primary:hover:not(:disabled){background:#2ea043}
button.ghost{background:transparent}
.grid{display:grid;grid-template-columns:150px 1fr;gap:11px 14px;align-items:center}
label{color:#c9d1d9;font-size:13px}
select,input[type=number]{width:100%;font:inherit;font-size:13px;padding:7px 10px;border-radius:7px;border:1px solid #30363d;background:#0d1117;color:#e6edf3}
.checks{margin-top:14px;display:flex;flex-direction:column;gap:9px}
.checks label{display:flex;gap:9px;align-items:flex-start;cursor:pointer;color:#c9d1d9}
input[type=checkbox]{margin:2px 0 0;accent-color:#2ea043;width:15px;height:15px}
.hint{color:#6e7681;font-size:12px;display:block}
.barwrap{height:7px;background:#21262d;border-radius:4px;overflow:hidden;margin:15px 0 9px}
.bar{height:100%;width:0;background:linear-gradient(90deg,#2ea043,#4f8cff);transition:width .25s}
.status{color:#8b949e;font-size:13px;min-height:20px}
pre.log{background:#0d1117;border:1px solid #21262d;border-radius:7px;padding:11px 13px;max-height:190px;overflow:auto;font-family:ui-monospace,Menlo,monospace;font-size:12px;color:#8b949e;margin:0;white-space:pre-wrap}
.result{border-color:#2ea043}
.result .big{font-size:16px;color:#e6edf3;margin-bottom:5px}
.warn{color:#d29922;font-size:12.5px;margin-top:7px}
.err{color:#f85149}
.hidden{display:none}
.credit{margin:26px 0 0;color:#6e7681;font-size:12.5px;text-align:center;line-height:1.7}
.credit a{color:#8b949e}
.banner{background:#3d2a12;border:1px solid #9e6a03;color:#e3b341;padding:11px 14px;border-radius:8px;margin-bottom:16px;font-size:13px}
</style></head><body><div class="wrap">
<h1>Syncflow</h1>
<p class="sub">Aligns every camera and recorder by their audio, then orders takes by when they were shot.</p>

<div id="ffmpegwarn" class="banner hidden">
  <b>ffmpeg was not found.</b> Open Terminal and run <code>brew install ffmpeg</code>, then reopen Syncflow.
</div>

<div class="card"><h2>Footage</h2>
  <div id="src" class="pathbox">Nothing selected yet</div>
  <div class="row">
    <button onclick="pick('file')">Choose XML…</button>
    <button onclick="pick('folder')">Choose Folder…</button>
  </div>
</div>

<div class="card"><h2>Save synced sequence to</h2>
  <div id="dst" class="pathbox">Chosen automatically</div>
</div>

<div class="card"><h2>Options</h2>
  <div class="grid">
    <label for="format">Editor</label>
    <select id="format" onchange="refreshOut()">
      <option value="xmeml">Premiere Pro, Resolve, Vegas, Media Composer</option>
      <option value="fcpxml">Final Cut Pro</option>
    </select>
    <label for="order">Take order</label>
    <select id="order">
      <option value="chronological">Chronological — back to back, in recording order</option>
      <option value="timestamp">Real time — keep the gaps of the shooting day</option>
      <option value="stack">Stacked — every take starts at zero</option>
    </select>
    <label for="strict">Matching</label>
    <select id="strict">
      <option value="0.25">Normal</option>
      <option value="0.40">Strict — fewer wrong matches</option>
      <option value="0.15">Loose — catches difficult audio</option>
    </select>
    <label for="channel">Audio channels</label>
    <select id="channel">
      <option value="mix">Mix both channels</option>
      <option value="first">Channel 1 only — split mics or out of phase</option>
    </select>
    <label for="gap">Gap between takes</label>
    <input id="gap" type="number" min="0" max="120" step="1" value="2">
  </div>
  <div class="checks">
    <label><input type="checkbox" id="mute"><span>Drop camera audio where a recorder covers the take
      <span class="hint">Halves the track count. Camera scratch audio is rarely used.</span></span></label>
    <label><input type="checkbox" id="drift"><span>Check for clock drift
      <span class="hint">Slower. Worth it on takes over ten minutes.</span></span></label>
    <label><input type="checkbox" id="multicam"><span>Create multicam clips
      <span class="hint">Final Cut only; ignored for other editors.</span></span></label>
  </div>
</div>

<div class="card">
  <div class="row">
    <button id="go" class="primary" onclick="start()">Sync</button>
    <button id="stop" class="ghost" onclick="cancel()" disabled>Cancel</button>
  </div>
  <div class="barwrap"><div id="bar" class="bar"></div></div>
  <div id="status" class="status">Choose an XML from your editor, or a folder of footage.</div>
</div>

<div class="card"><h2>Details</h2><pre id="log" class="log">Ready.</pre></div>

<div id="result" class="card result hidden">
  <div id="resultText" class="big"></div>
  <div id="resultWarn"></div>
  <div class="row">
    <button onclick="openThing('report')">Open Report</button>
    <button onclick="openThing('reveal')">Show Sequence in Finder</button>
  </div>
</div>

<div class="row"><button class="ghost" onclick="quitApp()">Quit Syncflow</button></div>
<p class="credit">Syncflow is free to use and share.
Built by <a href="https://dancharlton.net" target="_blank" rel="noopener">Dan Charlton</a>,
motion designer &mdash; <a href="https://dancharlton.net" target="_blank" rel="noopener">dancharlton.net</a></p>
</div>
<script>
const TOKEN="__TOKEN__";
let input="", output="", busy=false, lastLog="";

async function api(path, body){
  const r = await fetch(path, {
    method: body===undefined ? "GET" : "POST",
    headers: {"X-Syncflow-Token": TOKEN, "Content-Type":"application/json"},
    body: body===undefined ? undefined : JSON.stringify(body)
  });
  return r.json();
}
const fmt = v => v || "";

async function pick(kind){
  const r = await api("/api/pick", {kind, format: document.getElementById("format").value});
  if(!r.path) return;
  input = r.path; output = r.output;
  const s=document.getElementById("src"); s.textContent=input; s.classList.add("set");
  const d=document.getElementById("dst"); d.textContent=output; d.classList.add("set");
  document.getElementById("status").textContent="Ready.";
}
async function refreshOut(){
  if(!input) return;
  const r = await api("/api/default-output", {path: input, format: document.getElementById("format").value});
  output = r.output;
  document.getElementById("dst").textContent = output;
}
async function start(){
  if(!input){ document.getElementById("status").textContent="Choose footage first."; return; }
  document.getElementById("result").classList.add("hidden");
  await api("/api/start", {
    input, output,
    format:   document.getElementById("format").value,
    order:    document.getElementById("order").value,
    min_confidence: parseFloat(document.getElementById("strict").value),
    channel:  document.getElementById("channel").value,
    gap:      parseFloat(document.getElementById("gap").value || "2"),
    mute_camera_audio: document.getElementById("mute").checked,
    drift:    document.getElementById("drift").checked,
    multicam: document.getElementById("multicam").checked
  });
}
const cancel   = () => api("/api/cancel", {});
const openThing= w  => api("/api/open", {which:w});
async function quitApp(){ await api("/api/quit", {}); document.body.innerHTML=
  '<div class="wrap"><h1>Syncflow closed</h1><p class="sub">You can close this tab.</p></div>'; }

async function poll(){
  let s;
  try { s = await api("/api/state"); } catch(e) { return; }
  document.getElementById("ffmpegwarn").classList.toggle("hidden", s.ffmpeg !== false);
  document.getElementById("bar").style.width = (s.progress*100).toFixed(1)+"%";
  document.getElementById("status").innerHTML = s.error
    ? '<span class="err">'+fmt(s.error)+'</span>' : fmt(s.message);
  const text = s.log.length ? s.log.join("\n") : "Ready.";
  if(text !== lastLog){ lastLog = text;
    const l=document.getElementById("log"); l.textContent=text; l.scrollTop=l.scrollHeight; }
  if(s.running !== busy){
    busy = s.running;
    document.getElementById("go").disabled = busy;
    document.getElementById("stop").disabled = !busy;
  }
  if(s.summary){
    const m = s.summary;
    document.getElementById("resultText").textContent =
      m.synced+" of "+m.sources+" files synced into "+m.takes+" take"+(m.takes===1?"":"s")
      +" — "+m.duration+" timeline, reference camera "+m.anchor+".";
    document.getElementById("resultWarn").innerHTML =
      (m.unsynced ? '<div class="warn">'+m.unsynced+' file(s) could not be matched. They are in the sequence, placed by timestamp and labelled red.</div>' : '')
      + m.warnings.map(w => '<div class="warn">'+w+'</div>').join('');
    document.getElementById("result").classList.remove("hidden");
  }
}
setInterval(poll, 500); poll();
</script></body></html>
"""


def main(argv: list[str] | None = None) -> int:
    token = secrets.token_urlsafe(24)
    server = Server(("127.0.0.1", 0), Handler, token)
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/"

    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"Syncflow is running at {url}")
    webbrowser.open(url)

    # Quit once the page stops checking in, so closing the tab closes the app.
    try:
        while not server.should_quit.is_set():
            time.sleep(1.0)
            idle = time.time() - server.last_ping
            with server.job.lock:
                working = server.job.running
            if idle > HEARTBEAT_TIMEOUT and not working:
                break
    except KeyboardInterrupt:
        pass
    server.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
