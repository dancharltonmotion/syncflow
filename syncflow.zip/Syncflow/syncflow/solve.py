"""Turn pairwise audio matches into one globally consistent timeline.

Pairwise offsets are noisy and, worse, occasionally confidently wrong (rooms
with repeating music, long stretches of identical room tone). So we do not
just chain them. We build a graph, then solve all offsets in a connected
component at once with an iteratively-reweighted least squares fit. That does
three useful things:

  * over-determined loops average out, so accuracy improves with more cameras
  * an edge that disagrees with the consensus gets down-weighted, then flagged
  * every edge ends up with a residual you can actually inspect
"""

from __future__ import annotations

import itertools
import threading
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from typing import Callable, Optional

import numpy as np

from . import align
from .align import Match
from .media import ANALYSIS_SR, Cache, decode_audio, is_silent
from .model import Edge, Project, Source, SyncGroup


class Analyzer:
    """Lazily decodes and caches audio + onset features for each source."""

    def __init__(self, cache: Cache, channel_mode: str = "mix",
                 audio_budget_mb: int = 1500):
        self.cache = cache
        self.channel_mode = channel_mode
        self._feat: dict[str, np.ndarray] = {}
        self._audio: dict[str, np.ndarray] = {}
        self._audio_bytes = 0
        self._budget = audio_budget_mb * 1024 * 1024
        self._lock = threading.Lock()

    def audio(self, src: Source) -> np.ndarray:
        with self._lock:
            hit = self._audio.get(src.id)
        if hit is not None:
            return hit
        a = decode_audio(src.path, ANALYSIS_SR, self.channel_mode, cache=self.cache)
        with self._lock:
            if self._audio_bytes + a.nbytes <= self._budget:
                self._audio[src.id] = a
                self._audio_bytes += a.nbytes
        return a

    def features(self, src: Source) -> np.ndarray:
        with self._lock:
            hit = self._feat.get(src.id)
        if hit is not None:
            return hit

        key = self.cache.key(src.path, f"onset|{self.channel_mode}|"
                                       f"{align.N_FFT}|{align.HOP}|{align.N_BANDS}")
        f = self.cache.get_npy(key)
        if f is None:
            a = self.audio(src)
            src.silent = is_silent(a)
            f = align.onset_bands(a)
            self.cache.put_npy(key, f)
        with self._lock:
            self._feat[src.id] = f
        return f

    def release_audio(self) -> None:
        with self._lock:
            self._audio.clear()
            self._audio_bytes = 0


# --------------------------------------------------------------------------
# Pairwise stage
# --------------------------------------------------------------------------

def match_pair(an: Analyzer, a: Source, b: Source, *, do_refine: bool = True,
               do_drift: bool = False, min_conf: float = 0.15) -> Optional[Match]:
    fa, fb = an.features(a), an.features(b)
    if fa.shape[1] < 8 or fb.shape[1] < 8:
        return None
    m = align.coarse_match(fa, fb)
    if not m.ok or m.confidence < min_conf:
        return m if m.ok else None

    if do_refine:
        try:
            wa, wb = an.audio(a), an.audio(b)
            new_off, peak = align.refine(wa, wb, ANALYSIS_SR, m.offset)
            if abs(new_off - m.offset) < 0.05:
                m.offset, m.refined = new_off, True
            if do_drift:
                m.drift_ppm = align.estimate_drift(wa, wb, ANALYSIS_SR, m.offset)
        except Exception:
            pass
    return m


def build_edges(project: Project, an: Analyzer, *, min_conf: float = 0.25,
                refine: bool = True, drift: bool = False, workers: int = 4,
                progress: Optional[Callable[[int, int, str], None]] = None,
                cancel: Optional[Callable[[], bool]] = None) -> list[Edge]:
    usable = [s for s in project.sources.values()
              if s.has_audio and not s.missing and s.duration > 0]

    # Pre-compute features (this is also where silence gets detected).
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(an.features, usable))
    if cancel and cancel():
        return []
    usable = [s for s in usable if not s.silent]
    for s in project.sources.values():
        if s.silent:
            project.warn(f"{s.name}: audio is effectively silent, will be "
                         f"placed by timestamp instead")

    pairs = list(itertools.combinations(usable, 2))
    total = len(pairs)
    edges: list[Edge] = []
    done = 0
    lock = threading.Lock()

    def work(pair):
        nonlocal done
        if cancel and cancel():
            return None
        a, b = pair
        try:
            m = match_pair(an, a, b, do_refine=refine, do_drift=drift,
                           min_conf=min_conf * 0.6)
        except Exception as exc:                      # never let one bad file stop a job
            project.warn(f"pair {a.name} / {b.name} failed: {exc}")
            m = None
        with lock:
            done += 1
            if progress:
                progress(done, total, f"{a.name} <-> {b.name}")
        if m and m.ok and m.confidence >= min_conf:
            return Edge(a=a.id, b=b.id, offset=m.offset, confidence=m.confidence,
                        ncc=m.ncc, drift_ppm=m.drift_ppm)
        return None

    with ThreadPoolExecutor(max_workers=workers) as ex:
        for e in ex.map(work, pairs):
            if e is not None:
                edges.append(e)
    return edges


# --------------------------------------------------------------------------
# Global solve
# --------------------------------------------------------------------------

def _components(node_ids: list[str], edges: list[Edge]) -> list[list[str]]:
    parent = {n: n for n in node_ids}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for e in edges:
        if e.rejected or e.a not in parent or e.b not in parent:
            continue
        ra, rb = find(e.a), find(e.b)
        if ra != rb:
            parent[ra] = rb

    buckets: dict[str, list[str]] = defaultdict(list)
    for n in node_ids:
        buckets[find(n)].append(n)
    return list(buckets.values())


def solve_offsets(project: Project, edges: list[Edge], *,
                  residual_tol: float = 0.08, iterations: int = 4) -> None:
    """Fill in ``Source.offset`` and ``Source.group`` for every source."""
    node_ids = list(project.sources.keys())
    comps = _components(node_ids, edges)
    # Biggest component first so group 0 is the main body of the shoot.
    comps.sort(key=len, reverse=True)

    by_pair = defaultdict(list)
    for e in edges:
        by_pair[(e.a, e.b)].append(e)

    project.groups = []
    for gi, comp in enumerate(comps):
        idx = {n: i for i, n in enumerate(comp)}
        comp_edges = [e for e in edges if e.a in idx and e.b in idx and not e.rejected]

        if len(comp) == 1 or not comp_edges:
            project.sources[comp[0]].offset = 0.0
            project.sources[comp[0]].group = gi
            project.sources[comp[0]].confidence = 0.0
        else:
            w = np.array([e.confidence for e in comp_edges], dtype=np.float64)
            d = np.array([e.offset for e in comp_edges], dtype=np.float64)

            # Anchor: the best-connected node in the component.
            deg = defaultdict(float)
            for e in comp_edges:
                deg[e.a] += e.confidence
                deg[e.b] += e.confidence
            anchor = max(comp, key=lambda n: deg[n])

            t = np.zeros(len(comp))
            for _ in range(iterations):
                A = np.zeros((len(comp_edges) + 1, len(comp)))
                for r, e in enumerate(comp_edges):
                    A[r, idx[e.b]] = 1.0
                    A[r, idx[e.a]] = -1.0
                A[-1, idx[anchor]] = 1.0
                b = np.concatenate([d, [0.0]])
                weights = np.concatenate([w, [w.max() * 10 if w.size else 1.0]])
                Aw = A * weights[:, None]
                bw = b * weights
                t, *_ = np.linalg.lstsq(Aw, bw, rcond=None)

                resid = A[:-1] @ t - d
                # Huber-ish reweighting: outlier edges lose influence.
                w = np.array([e.confidence for e in comp_edges]) / (
                    1.0 + (np.abs(resid) / residual_tol) ** 2)

            resid = np.array([t[idx[e.b]] - t[idx[e.a]] - e.offset for e in comp_edges])
            for e, r in zip(comp_edges, resid):
                e.residual = float(r)
                if abs(r) > residual_tol * 4:
                    e.rejected = True
                    project.warn(
                        f"inconsistent match {project.sources[e.a].name} <-> "
                        f"{project.sources[e.b].name} (off by {r*1000:.0f} ms) - "
                        f"down-weighted; check this pair")

            t -= t.min()
            conf = defaultdict(list)
            for e in comp_edges:
                if not e.rejected:
                    conf[e.a].append(e.confidence)
                    conf[e.b].append(e.confidence)
            for n in comp:
                s = project.sources[n]
                s.offset = float(t[idx[n]])
                s.group = gi
                s.confidence = float(max(conf[n])) if conf[n] else 0.0
                dr = [abs(e.drift_ppm) for e in comp_edges
                      if n in (e.a, e.b) and e.drift_ppm]
                s.drift_ppm = max(dr) if dr else 0.0

        # Normalise the group so its earliest source sits at 0.
        offs = [project.sources[n].offset for n in comp]
        base = min(offs)
        span = 0.0
        for n in comp:
            s = project.sources[n]
            s.offset -= base
            span = max(span, s.offset + s.duration)

        g = SyncGroup(index=gi, source_ids=list(comp), span=span)
        g.confidence = float(np.mean([project.sources[n].confidence for n in comp]))
        project.groups.append(g)

    _learn_timestamp_anchor(project)
    _date_groups(project)


# --------------------------------------------------------------------------
# Creation-time handling
# --------------------------------------------------------------------------

def _self_consistency(srcs: list[Source]) -> Optional[str]:
    """Does this device stamp files at the start or the end of the recording?

    Consecutive clips from one camera cannot overlap in real time. Under
    start-stamping, gap(i) >= duration(i-1); under end-stamping,
    gap(i) >= duration(i). When the two clips have different lengths, only one
    hypothesis survives.
    """
    dated = sorted([s for s in srcs if s.created_at and s.duration > 0],
                   key=lambda s: s.created_at)
    if len(dated) < 2:
        return None
    viol = {"start": 0, "end": 0}
    tested = 0
    for a, b in zip(dated, dated[1:]):
        gap = (b.created_at - a.created_at).total_seconds()
        if abs(a.duration - b.duration) < 1.0:
            continue                      # cannot discriminate
        tested += 1
        if gap < a.duration - 1.0:
            viol["start"] += 1
        if gap < b.duration - 1.0:
            viol["end"] += 1
    if not tested:
        return None
    if viol["start"] and not viol["end"]:
        return "end"
    if viol["end"] and not viol["start"]:
        return "start"
    return None


def _learn_timestamp_anchor(project: Project) -> None:
    """Decide, per device, whether ``creation_time`` marks the start or the end
    of the recording. Cameras genuinely disagree about this (most stamp the
    start; several Canon and AVCHD models stamp the stop), and getting it wrong
    reverses the chronological order of a whole shoot.

    Two independent signals: each device's own file spacing, and agreement with
    the audio sync we have just solved.
    """
    per_device: dict[str, list[Source]] = defaultdict(list)
    for s in project.sources.values():
        if s.created_at and s.created_at_kind in ("unknown", "end", "start"):
            per_device[s.device or s.reel or "?"].append(s)
    if not per_device:
        return

    settled: dict[str, str] = {}
    for device, srcs in per_device.items():
        # mtime and filename stamps already have a known meaning.
        fixed = {s.created_at_source for s in srcs}
        if fixed <= {"filename"}:
            settled[device] = "start"
            continue
        if fixed <= {"mtime"}:
            settled[device] = "end"
            continue
        guess = _self_consistency(srcs)
        if guess:
            settled[device] = guess

    # Reference device: the one with the strongest metadata, then the one we
    # already settled, then the busiest. Never anchor on file mtime if a real
    # container timestamp exists anywhere in the project.
    rank = {"quicktime": 0, "exif": 0, "container": 1, "filename": 2, "mtime": 3}

    def weight(d):
        best = min(rank.get(s.created_at_source, 4) for s in per_device[d])
        return (-best, d in settled, len(per_device[d]))

    ref_device = max(per_device, key=weight)
    settled.setdefault(ref_device, "start")

    def stamp(s: Source, kind: str):
        ts = s.created_at
        return ts - timedelta(seconds=s.duration) if kind == "end" else ts

    ref_kind = settled[ref_device]
    for device, srcs in per_device.items():
        if device in settled:
            continue
        scores = {}
        for kind in ("start", "end"):
            errs = []
            for g in project.groups:
                mine = [s for s in srcs if s.id in g.source_ids]
                refs = [project.sources[n] for n in g.source_ids
                        if project.sources[n].device == ref_device
                        and project.sources[n].created_at]
                for s in mine:
                    for o in refs:
                        implied = (stamp(s, kind) - stamp(o, ref_kind)).total_seconds()
                        actual = (s.offset or 0.0) - (o.offset or 0.0)
                        errs.append(abs(implied - actual))
            scores[kind] = float(np.median(errs)) if errs else float("inf")
        if scores["end"] < scores["start"] and scores["end"] < 60:
            settled[device] = "end"
        else:
            settled[device] = "start"
        if min(scores.values()) > 120:
            project.warn(f"{device}: creation timestamps disagree with the audio "
                         f"sync by ~{min(scores.values()):.0f}s - clock may be "
                         f"set wrong; ordering will rely on other devices")

    for device, srcs in per_device.items():
        for s in srcs:
            if s.created_at_source not in ("filename", "mtime"):
                s.created_at_kind = settled.get(device, "start")


def _date_groups(project: Project) -> None:
    """Give each sync group a wall-clock start time, using the earliest
    trustworthy creation timestamp among its members (offset-corrected)."""
    rank = {"quicktime": 0, "exif": 0, "container": 1, "filename": 2, "mtime": 3}
    for g in project.groups:
        cands = []
        for n in g.source_ids:
            s = project.sources[n]
            cs = s.created_start
            if cs is None:
                continue
            # Back out this source's position within the group so every member
            # votes for the same instant: the group's t=0.
            cands.append((rank.get(s.created_at_source, 4),
                          cs - timedelta(seconds=s.offset or 0.0)))
        if not cands:
            continue
        best_rank = min(c[0] for c in cands)
        picks = [c[1] for c in cands if c[0] == best_rank]
        picks.sort()
        g.start_time = picks[len(picks) // 2]      # median is robust to one bad clock
