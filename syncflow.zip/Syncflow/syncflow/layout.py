"""Lay solved sources out onto a timeline.

Two decisions live here:

  ORDER  - where each sync group (take) sits along the timeline. The default
           follows the brief: pick the video device holding the most footage
           as the anchor, then order takes by creation timestamp.

  LANES  - which track each clip lands on. One device = one track for the whole
           sequence, so V1 is always Camera A and never becomes Camera B
           halfway down the timeline. That is the thing that makes the output
           usable as a multicam source.
"""

from __future__ import annotations

import os
import re
from collections import defaultdict
from datetime import timedelta
from typing import Optional

from .model import Clip, Project, Source

_TRAILING_NUM = re.compile(r"[\s_\-]*\d+$")


def _stem_class(name: str) -> str:
    stem = os.path.splitext(name)[0]
    stem = _TRAILING_NUM.sub("", stem)
    return stem.upper()[:24] or "CLIP"


def assign_devices(project: Project, use_tracks: bool = True) -> None:
    """Cluster sources into physical devices (cameras / recorders)."""
    # Primary identity: the filename family (C0001/C0002 -> "C", ZOOM0001 -> "ZOOM"),
    # which is how cameras actually name their cards. Technical specs are only
    # appended when two families would otherwise collide.
    spec: dict[str, set[str]] = defaultdict(set)
    for s in project.sources.values():
        if s.device:
            continue
        s._family = s.reel or _stem_class(s.name)
        if s.has_video:
            s._spec = f"{s.width}x{s.height} {s.rate}"
        else:
            s._spec = f"audio {s.audio_channels}ch"
        spec[s._family].add(s._spec)

    for s in project.sources.values():
        if s.device:
            continue
        fam = s._family
        s.device = fam if len(spec[fam]) == 1 else f"{fam} ({s._spec})"

    # Original track membership only settles one question: two cameras that use
    # the same card naming scheme (both writing C0001.MXF) but were laid onto
    # separate tracks are genuinely separate devices. Track *names* are usually
    # meaningless ("V1"), so they are never used as labels.
    if use_tracks:
        tracks_of: dict[str, set[str]] = defaultdict(set)
        families_on: dict[str, set[str]] = defaultdict(set)
        for c in project.clips:
            if c.orig_track:
                tracks_of[c.source.device].add(c.orig_track)
                families_on[c.orig_track].add(c.source.device)
        for family, tracks in tracks_of.items():
            if len(tracks) > 1 and all(len(families_on[t]) == 1 for t in tracks):
                for c in project.clips:
                    if c.source.device == family and c.orig_track:
                        c.source.device = f"{family} [{c.orig_track}]"


def device_totals(project: Project) -> dict[str, float]:
    totals: dict[str, float] = defaultdict(float)
    for s in project.sources.values():
        totals[s.device] += s.duration
    return dict(totals)


def anchor_device(project: Project) -> Optional[str]:
    """The video device with the most footage - our chronological reference."""
    totals: dict[str, float] = defaultdict(float)
    for s in project.sources.values():
        if s.has_video:
            totals[s.device] += s.duration
    if not totals:
        totals = device_totals(project)
    return max(totals, key=totals.get) if totals else None


# --------------------------------------------------------------------------
# Ordering
# --------------------------------------------------------------------------

def order_groups(project: Project, mode: str = "chronological",
                 gap: float = 2.0, anchor: Optional[str] = None) -> None:
    """Set ``SyncGroup.timeline_start`` for every group.

    modes:
      chronological - takes back to back in creation-date order, ``gap``
                      seconds apart. Compact and easy to scrub.
      timestamp     - real wall-clock spacing preserved. The timeline becomes a
                      map of the shooting day; great for spotting missing takes.
      stack         - every take starts at 0, for reviewing one take at a time.
      keep          - preserve the order the groups came out of the solver.
    """
    anchor = anchor or anchor_device(project)

    def sort_key(g):
        if g.start_time is not None:
            return (0, g.start_time.timestamp())
        # No date at all: fall back to whichever anchor-device source we have.
        for n in g.source_ids:
            s = project.sources[n]
            if s.device == anchor and s.created_start:
                return (0, s.created_start.timestamp())
        return (1, g.index)

    groups = sorted(project.groups, key=sort_key)

    if mode == "stack":
        for g in groups:
            g.timeline_start = 0.0
        return

    if mode == "keep":
        groups = project.groups

    if mode == "timestamp":
        dated = [g for g in groups if g.start_time is not None]
        if dated:
            t0 = min(g.start_time for g in dated)
            cursor = 0.0
            for g in groups:
                if g.start_time is not None:
                    g.timeline_start = (g.start_time - t0).total_seconds()
                    cursor = max(cursor, g.timeline_start + g.span + gap)
                else:
                    g.timeline_start = cursor
                    cursor += g.span + gap
            lo = min(g.timeline_start for g in groups)
            for g in groups:
                g.timeline_start -= lo
            return
        mode = "chronological"

    cursor = 0.0
    for g in groups:
        g.timeline_start = cursor
        cursor += g.span + gap


def apply_offsets(project: Project) -> None:
    """Push solved source offsets + group placement down onto every clip."""
    gpos = {g.index: g.timeline_start for g in project.groups}
    for c in project.clips:
        s = c.source
        base = gpos.get(s.group, 0.0) + (s.offset or 0.0)
        c.timeline_start = base + c.src_in


# --------------------------------------------------------------------------
# Lane assignment
# --------------------------------------------------------------------------

def assign_tracks(project: Project, anchor: Optional[str] = None) -> dict:
    """Give every clip a video and/or audio track index (1-based).

    Devices are ranked by total footage, so the anchor camera lands on V1 and
    the busiest recorder on the lowest free audio track. Overlapping clips from
    the same device spill onto extra lanes rather than being dropped.
    """
    anchor = anchor or anchor_device(project)
    totals = device_totals(project)

    video_devs = sorted({s.device for s in project.sources.values() if s.has_video},
                        key=lambda d: (d != anchor, -totals.get(d, 0.0), d))
    audio_only = sorted({s.device for s in project.sources.values()
                         if s.has_audio and not s.has_video},
                        key=lambda d: (-totals.get(d, 0.0), d))

    v_lane = {d: i + 1 for i, d in enumerate(video_devs)}
    # Camera audio sits under its own camera; external recorders go below.
    a_lane = {d: i + 1 for i, d in enumerate(video_devs)}
    for i, d in enumerate(audio_only):
        a_lane[d] = len(video_devs) + i + 1

    occupied_v: dict[int, list[Clip]] = defaultdict(list)
    occupied_a: dict[int, list[Clip]] = defaultdict(list)

    def place(clip: Clip, lane: int, table: dict[int, list[Clip]], stride: int) -> int:
        cur = lane
        for _ in range(64):
            if not any(clip.overlaps(o) for o in table[cur]):
                table[cur].append(clip)
                return cur
            cur += stride
        table[cur].append(clip)
        return cur

    for c in sorted(project.clips, key=lambda c: c.timeline_start):
        s = c.source
        if s.has_video:
            c.track_v = place(c, v_lane.get(s.device, len(v_lane) + 1),
                              occupied_v, max(1, len(v_lane)))
        if s.has_audio and not s.silent:
            c.track_a = place(c, a_lane.get(s.device, len(a_lane) + 1),
                              occupied_a, max(1, len(a_lane)))

    return {
        "anchor": anchor,
        "video_tracks": max(occupied_v.keys(), default=0),
        "audio_tracks": max(occupied_a.keys(), default=0),
        "video_lane": v_lane,
        "audio_lane": a_lane,
        "device_totals": totals,
    }


def mute_camera_audio(project: Project, keep_devices: Optional[set[str]] = None) -> int:
    """Drop camera-mic audio where an external recorder covers the same take.

    Camera scratch audio is almost always thrown away in the edit, and leaving
    it in doubles the track count for no benefit.
    """
    recorder_devices = {s.device for s in project.sources.values()
                        if s.has_audio and not s.has_video}
    if not recorder_devices:
        return 0
    covered = {g.index for g in project.groups
               if any(project.sources[n].device in recorder_devices
                      for n in g.source_ids)}
    n = 0
    for c in project.clips:
        s = c.source
        if (s.has_video and s.has_audio and s.group in covered
                and (not keep_devices or s.device not in keep_devices)):
            c.track_a = None
            n += 1
    return n


def trim_handles(project: Project, head: float = 0.0, tail: float = 0.0) -> None:
    """Shave unusable frames off the head/tail of every clip (rolling shutter
    settling, autofocus hunting, the operator reaching for the stop button)."""
    if head <= 0 and tail <= 0:
        return
    for c in project.clips:
        if c.duration > head + tail + 0.5:
            c.src_in += head
            c.src_out -= tail
            c.timeline_start += head


def drop_short(project: Project, min_seconds: float) -> int:
    if min_seconds <= 0:
        return 0
    before = len(project.clips)
    project.clips = [c for c in project.clips if c.duration >= min_seconds]
    return before - len(project.clips)
