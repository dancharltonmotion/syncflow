"""Core data model.

The pipeline is deliberately split into two levels:

  Source  -- a unique media file on disk. Audio analysis happens here, once
             per file, no matter how many times the file appears on a timeline.
  Clip    -- one *use* of a Source on a timeline (a subclip with in/out points).

Sync offsets are solved between Sources. A Clip's timeline position is then
just ``source.offset + clip.src_in``. This is what makes re-syncing a project
that already has an edit in it cheap and stable.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional


# --------------------------------------------------------------------------
# Frame rate handling
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Rate:
    """An NLE frame rate. ``timebase`` is the integer base, ``ntsc`` pulls it
    down by 1000/1001 (so 30 + ntsc = 29.97, 24 + ntsc = 23.976)."""

    timebase: int = 25
    ntsc: bool = False

    @property
    def fps(self) -> float:
        return self.timebase * (1000.0 / 1001.0 if self.ntsc else 1.0)

    def to_frames(self, seconds: float) -> int:
        return int(round(seconds * self.fps))

    def to_seconds(self, frames: int) -> float:
        return frames / self.fps

    @classmethod
    def from_fps(cls, fps: float) -> "Rate":
        """Best-effort mapping of a float fps onto an NLE (timebase, ntsc) pair."""
        candidates = [
            (24, True, 23.976), (24, False, 24.0), (25, False, 25.0),
            (30, True, 29.97), (30, False, 30.0), (48, False, 48.0),
            (50, False, 50.0), (60, True, 59.94), (60, False, 60.0),
            (100, False, 100.0), (120, True, 119.88), (120, False, 120.0),
        ]
        best = min(candidates, key=lambda c: abs(c[2] - fps))
        if abs(best[2] - fps) > 0.5:  # something exotic - round it
            return cls(int(round(fps)), False)
        return cls(best[0], best[1])

    def __str__(self) -> str:
        return f"{self.fps:.3f}".rstrip("0").rstrip(".") + " fps"


# --------------------------------------------------------------------------
# Sources
# --------------------------------------------------------------------------

@dataclass
class Source:
    """A unique media file."""

    id: str
    path: str                      # absolute filesystem path (may not exist yet)
    name: str
    duration: float = 0.0          # seconds
    has_video: bool = False
    has_audio: bool = False
    width: int = 0
    height: int = 0
    par: float = 1.0               # pixel aspect ratio
    rate: Rate = field(default_factory=Rate)
    audio_channels: int = 0
    audio_rate: int = 48000

    # --- metadata used for ordering -------------------------------------
    created_at: Optional[datetime] = None
    created_at_kind: str = "none"      # start | end | unknown | none
    created_at_source: str = ""        # where we got it: quicktime, exif, name, mtime
    start_timecode: Optional[float] = None   # seconds, from embedded TC track
    reel: str = ""                     # camera / reel / device name if known

    # --- filled in by analysis ------------------------------------------
    missing: bool = False
    silent: bool = False               # has an audio stream but it is dead quiet
    offset: Optional[float] = None      # solved position on the master timeline
    group: Optional[int] = None
    confidence: float = 0.0
    drift_ppm: float = 0.0
    device: str = ""                    # resolved camera/recorder identity
    _family: str = ""
    _spec: str = ""

    @property
    def kind(self) -> str:
        if self.has_video and self.has_audio:
            return "av"
        if self.has_video:
            return "video"
        if self.has_audio:
            return "audio"
        return "unknown"

    @property
    def created_start(self) -> Optional[datetime]:
        """Creation time normalised to the *start* of the recording."""
        if self.created_at is None:
            return None
        if self.created_at_kind == "end":
            return self.created_at - timedelta(seconds=self.duration)
        return self.created_at


# --------------------------------------------------------------------------
# Clips
# --------------------------------------------------------------------------

@dataclass
class Clip:
    """One use of a Source on a timeline."""

    id: str
    source: Source
    src_in: float = 0.0            # seconds into the source file
    src_out: float = 0.0           # seconds into the source file (exclusive)
    name: str = ""
    orig_track: str = ""           # track it came in on, useful as a device hint
    enabled: bool = True
    label: str = ""                # NLE colour label, passed through
    # filled in by the layout stage
    timeline_start: float = 0.0
    track_v: Optional[int] = None
    track_a: Optional[int] = None

    @property
    def duration(self) -> float:
        return max(0.0, self.src_out - self.src_in)

    @property
    def timeline_end(self) -> float:
        return self.timeline_start + self.duration

    def overlaps(self, other: "Clip", pad: float = 0.0) -> bool:
        return (self.timeline_start < other.timeline_end + pad
                and other.timeline_start < self.timeline_end + pad)


# --------------------------------------------------------------------------
# Results
# --------------------------------------------------------------------------

@dataclass
class Edge:
    """A solved pairwise relationship between two sources."""
    a: str
    b: str
    offset: float          # seconds: position(b) - position(a)
    confidence: float
    ncc: float = 0.0
    drift_ppm: float = 0.0
    residual: float = 0.0  # after the global solve
    rejected: bool = False


@dataclass
class SyncGroup:
    """A connected component of sources that share audio - i.e. one take."""
    index: int
    source_ids: list[str] = field(default_factory=list)
    start_time: Optional[datetime] = None   # wall clock, for ordering
    span: float = 0.0                       # seconds, longest chain in group
    confidence: float = 0.0
    timeline_start: float = 0.0             # where the group lands on output


@dataclass
class Project:
    sources: dict[str, Source] = field(default_factory=dict)
    clips: list[Clip] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    groups: list[SyncGroup] = field(default_factory=list)
    rate: Rate = field(default_factory=Rate)
    sequence_name: str = "Synced Sequence"
    audio_rate: int = 48000
    width: int = 1920
    height: int = 1080
    source_format: str = "xmeml"
    warnings: list[str] = field(default_factory=list)

    def clips_for(self, source_id: str) -> list[Clip]:
        return [c for c in self.clips if c.source.id == source_id]

    def warn(self, msg: str) -> None:
        if msg not in self.warnings:
            self.warnings.append(msg)

    @property
    def duration(self) -> float:
        return max((c.timeline_end for c in self.clips), default=0.0)

    def stats(self) -> dict:
        # A source alone in its own group was not matched to anything; counting
        # it as "synced" would be a lie in the UI.
        multi = {g.index for g in self.groups if len(g.source_ids) > 1}
        synced = [s for s in self.sources.values()
                  if s.offset is not None and s.group in multi]
        return {
            "sources": len(self.sources),
            "clips": len(self.clips),
            "synced": len(synced),
            "unsynced": len(self.sources) - len(synced),
            "groups": len(self.groups),
            "multi_source_groups": len(multi),
            "duration": self.duration,
            "missing": sum(1 for s in self.sources.values() if s.missing),
            "silent": sum(1 for s in self.sources.values() if s.silent),
        }


def fmt_tc(seconds: float, rate: Rate) -> str:
    """Seconds -> HH:MM:SS:FF (non-drop)."""
    if seconds is None or math.isnan(seconds):
        return "--:--:--:--"
    sign = "-" if seconds < 0 else ""
    seconds = abs(seconds)
    total = int(round(seconds * rate.fps))
    tb = rate.timebase
    f = total % tb
    total //= tb
    s = total % 60
    total //= 60
    m = total % 60
    h = total // 60
    return f"{sign}{h:02d}:{m:02d}:{s:02d}:{f:02d}"
