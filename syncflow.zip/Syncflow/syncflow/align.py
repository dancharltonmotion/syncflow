"""The alignment engine.

Two stages, because they fail in different ways:

1. COARSE - multiband onset envelopes at ~62 Hz, matched with a properly
   normalised cross-correlation. Onset envelopes throw away level, EQ and
   phase, which is exactly what differs between a camera's on-board mic and a
   lav on a recorder. This searches the whole file cheaply and gives a
   trustworthy confidence number.

2. FINE - GCC-PHAT on band-limited raw audio inside a short, loud window near
   the coarse estimate, with parabolic interpolation. Takes the answer from
   ~16 ms accurate to sub-millisecond.

Confidence is the thing that actually matters in production. A wrong sync
delivered confidently is worse than no sync, so the score combines peak
height, peak prominence over the rest of the correlation, and how much
material actually overlapped.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.fft import next_fast_len, rfft, irfft

from .media import ANALYSIS_SR

# Feature parameters
N_FFT = 512
HOP = 128
FEATURE_SR = ANALYSIS_SR / HOP          # 62.5 Hz
N_BANDS = 6
BAND_EDGES = np.array([60, 200, 500, 1000, 1800, 2800, 3900], dtype=float)

MIN_OVERLAP_S = 2.0


@dataclass
class Match:
    offset: float = 0.0        # seconds: position(b) - position(a)
    confidence: float = 0.0    # 0..1
    ncc: float = 0.0           # raw normalised correlation peak
    prominence: float = 0.0
    overlap: float = 0.0       # seconds of overlapping material at the answer
    refined: bool = False
    drift_ppm: float = 0.0
    ok: bool = False


# --------------------------------------------------------------------------
# Feature extraction
# --------------------------------------------------------------------------

def onset_bands(audio: np.ndarray, sr: int = ANALYSIS_SR) -> np.ndarray:
    """Multiband half-wave-rectified spectral flux. Shape (N_BANDS, frames)."""
    if audio.size < N_FFT:
        return np.zeros((N_BANDS, 0), dtype=np.float32)

    n_frames = 1 + (audio.size - N_FFT) // HOP
    if n_frames < 4:
        return np.zeros((N_BANDS, 0), dtype=np.float32)

    window = np.hanning(N_FFT).astype(np.float32)
    # Strided view -> one big rfft. Memory is fine: 8 kHz mono, 512-pt frames.
    frames = np.lib.stride_tricks.as_strided(
        audio,
        shape=(n_frames, N_FFT),
        strides=(audio.strides[0] * HOP, audio.strides[0]),
        writeable=False,
    )
    spec = np.abs(rfft(frames * window, axis=1)).astype(np.float32)

    freqs = np.fft.rfftfreq(N_FFT, 1.0 / sr)
    out = np.zeros((N_BANDS, n_frames), dtype=np.float32)
    for b in range(N_BANDS):
        sel = (freqs >= BAND_EDGES[b]) & (freqs < BAND_EDGES[b + 1])
        if not sel.any():
            continue
        energy = np.log1p(spec[:, sel].mean(axis=1) * 1000.0)
        flux = np.diff(energy, prepend=energy[0])
        out[b] = np.maximum(flux, 0.0)

    # Per-band standardisation so a loud band cannot dominate the match.
    for b in range(N_BANDS):
        v = out[b]
        sd = v.std()
        out[b] = (v - v.mean()) / sd if sd > 1e-9 else 0.0
    return out


# --------------------------------------------------------------------------
# Normalised cross-correlation over unequal-length signals
# --------------------------------------------------------------------------

def _ncc_multiband(A: np.ndarray, B: np.ndarray,
                   min_overlap_frames: int) -> tuple[np.ndarray, np.ndarray]:
    """Return (ncc, lags) where ncc[k] scores 'B starts lags[k] frames after A'.

    The denominator is computed per-lag from the actual overlapping region
    (via cumulative sums), which is what stops the correlation from spiking on
    a two-frame overlap at the very edge of the search range.
    """
    na, nb = A.shape[1], B.shape[1]
    nfft = next_fast_len(na + nb)

    FA = rfft(A, n=nfft, axis=1)
    FB = rfft(B, n=nfft, axis=1)
    # numerator[k] = sum_t A[t] * B[t - k]  -> correlate(A, B)
    num = irfft(FA * np.conj(FB), n=nfft, axis=1).sum(axis=0)

    # Lags from -(nb-1) .. (na-1)
    num = np.concatenate([num[-(nb - 1):], num[:na]]) if nb > 1 else num[:na]
    lags = np.arange(-(nb - 1), na)

    # Per-lag energy of the overlapping slices, from cumulative sums.
    a2 = np.concatenate([[0.0], np.cumsum(np.square(A, dtype=np.float64).sum(axis=0))])
    b2 = np.concatenate([[0.0], np.cumsum(np.square(B, dtype=np.float64).sum(axis=0))])

    a_start = np.maximum(lags, 0)
    a_end = np.minimum(lags + nb, na)
    b_start = np.maximum(-lags, 0)
    b_end = np.minimum(na - lags, nb)
    n_ov = np.maximum(a_end - a_start, 0)

    ea = a2[np.clip(a_end, 0, na)] - a2[np.clip(a_start, 0, na)]
    eb = b2[np.clip(b_end, 0, nb)] - b2[np.clip(b_start, 0, nb)]
    denom = np.sqrt(np.maximum(ea * eb, 1e-12))

    ncc = num / denom
    ncc[n_ov < min_overlap_frames] = 0.0
    return ncc.astype(np.float32), lags


def coarse_match(A: np.ndarray, B: np.ndarray,
                 min_overlap_s: float = MIN_OVERLAP_S) -> Match:
    """Coarse align two onset-band feature matrices."""
    m = Match()
    if A.shape[1] < 8 or B.shape[1] < 8:
        return m

    min_ov = max(4, int(min_overlap_s * FEATURE_SR))
    ncc, lags = _ncc_multiband(A, B, min_ov)
    if not np.isfinite(ncc).any() or ncc.size == 0:
        return m

    peak_i = int(np.argmax(ncc))
    peak = float(ncc[peak_i])
    if peak <= 0:
        return m

    # Prominence: best value outside a +-0.5 s exclusion zone around the peak.
    excl = max(1, int(0.5 * FEATURE_SR))
    masked = ncc.copy()
    lo, hi = max(0, peak_i - excl), min(ncc.size, peak_i + excl + 1)
    masked[lo:hi] = -np.inf
    runner_up = float(np.max(masked)) if np.isfinite(masked).any() else 0.0
    prominence = 1.0 - max(runner_up, 0.0) / peak if peak > 0 else 0.0

    lag = int(lags[peak_i])
    overlap_frames = min(A.shape[1], lag + B.shape[1]) - max(lag, 0)

    m.offset = lag / FEATURE_SR
    m.ncc = peak
    m.prominence = float(np.clip(prominence, 0.0, 1.0))
    m.overlap = overlap_frames / FEATURE_SR

    # Confidence: peak height x prominence, softly gated on overlap length.
    # A 60 s overlap that correlates at 0.3 is far more believable than a 3 s
    # one at 0.6, hence the overlap term.
    ov_term = float(np.clip(np.log1p(m.overlap) / np.log1p(30.0), 0.0, 1.0))
    m.confidence = float(np.clip(peak, 0, 1) ** 0.5 * m.prominence * (0.4 + 0.6 * ov_term))
    m.ok = m.confidence > 0
    return m


# --------------------------------------------------------------------------
# Fine alignment: GCC-PHAT
# --------------------------------------------------------------------------

def _bandpass(x: np.ndarray, sr: int, lo: float, hi: float) -> np.ndarray:
    n = next_fast_len(x.size)
    X = rfft(x, n=n)
    f = np.fft.rfftfreq(n, 1.0 / sr)
    X[(f < lo) | (f > hi)] = 0
    return irfft(X, n=n)[: x.size]


def gcc_phat(a: np.ndarray, b: np.ndarray, sr: int,
             max_lag_s: float = 0.05) -> tuple[float, float]:
    """Return (lag_seconds, peak_value). Positive lag: b is delayed vs a."""
    if a.size < 64 or b.size < 64:
        return 0.0, 0.0
    n = next_fast_len(a.size + b.size)
    A = rfft(a - a.mean(), n=n)
    B = rfft(b - b.mean(), n=n)
    R = A * np.conj(B)
    mag = np.abs(R)
    R = np.divide(R, np.maximum(mag, 1e-10))
    cc = irfft(R, n=n)
    cc = np.concatenate([cc[-int(max_lag_s * sr):], cc[: int(max_lag_s * sr) + 1]])
    i = int(np.argmax(cc))
    peak = float(cc[i])
    # Parabolic interpolation for sub-sample accuracy.
    if 0 < i < cc.size - 1:
        y0, y1, y2 = cc[i - 1], cc[i], cc[i + 1]
        d = y0 - 2 * y1 + y2
        delta = 0.5 * (y0 - y2) / d if abs(d) > 1e-12 else 0.0
    else:
        delta = 0.0
    lag_samples = (i - int(max_lag_s * sr)) + delta
    return lag_samples / sr, peak


def _loudest_window(x: np.ndarray, sr: int, win_s: float) -> tuple[int, int]:
    """Index range of the highest-energy window - the best place to fine-align."""
    w = int(win_s * sr)
    if x.size <= w:
        return 0, x.size
    step = max(1, w // 4)
    energy = np.square(x, dtype=np.float64)
    csum = np.concatenate([[0.0], np.cumsum(energy)])
    starts = np.arange(0, x.size - w, step)
    sums = csum[starts + w] - csum[starts]
    s = int(starts[int(np.argmax(sums))])
    return s, s + w


def refine(a: np.ndarray, b: np.ndarray, sr: int, coarse_offset: float,
           window_s: float = 20.0, search_s: float = 0.05) -> tuple[float, float]:
    """Refine a coarse offset using GCC-PHAT on the loudest common region."""
    lag = int(round(coarse_offset * sr))
    # Overlapping region in a's index space
    lo = max(0, lag)
    hi = min(a.size, lag + b.size)
    if hi - lo < sr * 2:
        return coarse_offset, 0.0

    seg_a = a[lo:hi]
    s, e = _loudest_window(seg_a, sr, window_s)
    pad = int(search_s * sr) + 1
    a_lo, a_hi = lo + s, lo + e
    b_lo, b_hi = a_lo - lag - pad, a_hi - lag + pad
    if b_lo < 0 or b_hi > b.size:
        b_lo, b_hi = max(0, b_lo), min(b.size, b_hi)
        if b_hi - b_lo < sr:
            return coarse_offset, 0.0

    aw = _bandpass(a[a_lo:a_hi].astype(np.float64), sr, 200, 3500)
    bw = _bandpass(b[b_lo:b_hi].astype(np.float64), sr, 200, 3500)
    # Align the two windows' nominal start so gcc lag is a pure correction.
    nominal = (a_lo - lag) - b_lo
    delta, peak = gcc_phat(aw, bw[nominal:] if nominal > 0 else bw, sr,
                           max_lag_s=search_s)
    return coarse_offset + delta, peak


# --------------------------------------------------------------------------
# Clock drift
# --------------------------------------------------------------------------

def estimate_drift(a: np.ndarray, b: np.ndarray, sr: int, offset: float,
                   min_span_s: float = 180.0) -> float:
    """Estimate relative clock drift in ppm between two long recordings.

    Consumer recorders routinely run 20-200 ppm off nominal, which is ~1 frame
    of slip every 3-8 minutes. Worth reporting even when we cannot fix it.
    """
    lag = int(round(offset * sr))
    lo, hi = max(0, lag), min(a.size, lag + b.size)
    span = (hi - lo) / sr
    if span < min_span_s:
        return 0.0

    probes = []
    win = int(min(30.0, span / 6) * sr)
    for frac in (0.1, 0.5, 0.9):
        c = lo + int(frac * (hi - lo))
        a_lo, a_hi = c - win // 2, c + win // 2
        if a_lo < lo or a_hi > hi:
            continue
        b_lo, b_hi = a_lo - lag, a_hi - lag
        if b_lo < 0 or b_hi > b.size:
            continue
        aw = _bandpass(a[a_lo:a_hi].astype(np.float64), sr, 200, 3500)
        bw = _bandpass(b[b_lo:b_hi].astype(np.float64), sr, 200, 3500)
        d, peak = gcc_phat(aw, bw, sr, max_lag_s=0.08)
        if peak > 0.02:
            probes.append(((a_lo + a_hi) / 2 / sr, d))

    if len(probes) < 2:
        return 0.0
    t = np.array([p[0] for p in probes])
    d = np.array([p[1] for p in probes])
    slope = np.polyfit(t, d, 1)[0]
    return float(slope * 1e6)
