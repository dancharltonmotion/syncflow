"""A self-contained HTML review report.

The point is to make the sync auditable in ten seconds: which takes exist,
which sources landed in them, which pairs the solver was unsure about, and
whether any clock drift is going to bite you at the end of a long take.
"""

from __future__ import annotations

import html
import json
from datetime import datetime

from .model import Project, fmt_tc

PALETTE = ["#4f8cff", "#f0883e", "#3fb950", "#d2a8ff", "#f778ba",
           "#56d4dd", "#e3b341", "#a5d6ff", "#ff7b72", "#7ee787"]


def _bar(project: Project, width: int = 1000) -> str:
    total = max(project.duration, 1.0)
    devices = sorted({c.source.device for c in project.clips})
    colour = {d: PALETTE[i % len(PALETTE)] for i, d in enumerate(devices)}

    rows = []
    lanes: list[tuple[str, list]] = []
    for ti in sorted({c.track_v for c in project.clips if c.track_v}):
        lanes.append((f"V{ti}", [c for c in project.clips if c.track_v == ti]))
    for ti in sorted({c.track_a for c in project.clips if c.track_a}):
        lanes.append((f"A{ti}", [c for c in project.clips if c.track_a == ti]))

    for label, clips in lanes:
        blocks = []
        for c in sorted(clips, key=lambda c: c.timeline_start):
            left = c.timeline_start / total * 100
            w = max(0.08, c.duration / total * 100)
            conf = c.source.confidence
            title = (f"{c.name}\n{c.source.device}\n"
                     f"{fmt_tc(c.timeline_start, project.rate)} "
                     f"({c.duration:.1f}s)\nconfidence {conf:.2f}")
            blocks.append(
                f'<i style="left:{left:.4f}%;width:{w:.4f}%;'
                f'background:{colour.get(c.source.device, "#888")};'
                f'opacity:{0.45 + 0.55 * min(conf * 2, 1):.2f}" '
                f'title="{html.escape(title)}"></i>')
        rows.append(f'<div class="lane"><span>{label}</span><div class="strip">'
                    + "".join(blocks) + "</div></div>")

    marks = []
    for g in sorted(project.groups, key=lambda g: g.timeline_start):
        left = g.timeline_start / total * 100
        marks.append(f'<i style="left:{left:.4f}%" title="Take {g.index+1}"></i>')
    ruler = '<div class="lane"><span></span><div class="strip ruler">' + "".join(marks) + "</div></div>"

    legend = " ".join(
        f'<em style="background:{colour[d]}"></em>{html.escape(d)}' for d in devices)
    return ruler + "".join(rows) + f'<div class="legend">{legend}</div>'


def render(project: Project, info: dict) -> str:
    st = project.stats()
    srcs = sorted(project.sources.values(),
                  key=lambda s: (s.group if s.group is not None else 9999, s.offset or 0))

    src_rows = []
    for s in srcs:
        flags = []
        if s.missing:
            flags.append("MISSING")
        if s.silent:
            flags.append("silent")
        if abs(s.drift_ppm) > 20:
            flags.append(f"drift {s.drift_ppm:+.0f}ppm")
        if s.group is None:
            flags.append("unsynced")
        cls = "bad" if (s.missing or s.group is None) else (
            "warn" if s.confidence < 0.35 else "ok")
        src_rows.append(
            f"<tr class='{cls}'><td>{html.escape(s.name)}</td>"
            f"<td>{html.escape(s.device)}</td><td>{s.kind}</td>"
            f"<td>{s.duration:.1f}s</td>"
            f"<td>{'' if s.group is None else s.group + 1}</td>"
            f"<td>{'' if s.offset is None else f'{s.offset:+.3f}s'}</td>"
            f"<td>{s.confidence:.2f}</td>"
            f"<td>{s.created_start.strftime('%Y-%m-%d %H:%M:%S') if s.created_start else '-'}"
            f" <small>{s.created_at_source}/{s.created_at_kind}</small></td>"
            f"<td>{' '.join(flags)}</td></tr>")

    edge_rows = []
    for e in sorted(project.edges, key=lambda e: -abs(e.residual))[:60]:
        a, b = project.sources[e.a], project.sources[e.b]
        cls = "bad" if e.rejected else ("warn" if abs(e.residual) > 0.02 else "ok")
        edge_rows.append(
            f"<tr class='{cls}'><td>{html.escape(a.name)}</td>"
            f"<td>{html.escape(b.name)}</td><td>{e.offset:+.3f}s</td>"
            f"<td>{e.confidence:.2f}</td><td>{e.ncc:.2f}</td>"
            f"<td>{e.residual*1000:+.1f} ms</td>"
            f"<td>{'rejected' if e.rejected else ''}</td></tr>")

    group_rows = []
    for g in sorted(project.groups, key=lambda g: g.timeline_start):
        devs = sorted({project.sources[n].device for n in g.source_ids})
        group_rows.append(
            f"<tr><td>{g.index+1}</td><td>{len(g.source_ids)}</td>"
            f"<td>{fmt_tc(g.timeline_start, project.rate)}</td>"
            f"<td>{g.span:.1f}s</td><td>{g.confidence:.2f}</td>"
            f"<td>{g.start_time.strftime('%Y-%m-%d %H:%M:%S') if g.start_time else '-'}</td>"
            f"<td>{html.escape(', '.join(devs))}</td></tr>")

    warn_html = "".join(f"<li>{html.escape(w)}</li>" for w in project.warnings) \
        or "<li>None.</li>"

    return f"""<!doctype html>
<meta charset="utf-8"><title>Syncflow report - {html.escape(project.sequence_name)}</title>
<style>
:root{{color-scheme:dark}}
body{{background:#0d1117;color:#e6edf3;font:14px/1.5 ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0;padding:28px 32px}}
h1{{font-size:20px;margin:0 0 4px}} h2{{font-size:15px;margin:28px 0 10px;color:#9ba7b4;font-weight:600;text-transform:uppercase;letter-spacing:.06em}}
.sub{{color:#8b949e;margin-bottom:18px}}
.cards{{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:8px}}
.card{{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:10px 14px;min-width:96px}}
.card b{{display:block;font-size:22px;font-weight:600}} .card span{{color:#8b949e;font-size:12px}}
.lane{{display:flex;align-items:center;gap:8px;margin:2px 0}}
.lane>span{{width:34px;text-align:right;color:#8b949e;font-size:11px;font-variant-numeric:tabular-nums}}
.strip{{position:relative;flex:1;height:16px;background:#161b22;border:1px solid #21262d;border-radius:3px;overflow:hidden}}
.strip i{{position:absolute;top:0;bottom:0;border-radius:2px}}
.ruler{{height:8px;background:transparent;border:0}}
.ruler i{{width:1px;background:#6e7681;top:0;bottom:0}}
.legend{{margin-top:10px;color:#8b949e;font-size:12px;display:flex;gap:14px;flex-wrap:wrap;align-items:center}}
.legend em{{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}}
table{{border-collapse:collapse;width:100%;font-size:12.5px}}
th,td{{text-align:left;padding:5px 9px;border-bottom:1px solid #21262d;white-space:nowrap}}
th{{color:#8b949e;font-weight:600}}
tr.warn td:first-child{{box-shadow:inset 3px 0 #d29922}} tr.bad td:first-child{{box-shadow:inset 3px 0 #f85149}}
tr.ok td:first-child{{box-shadow:inset 3px 0 #3fb950}}
small{{color:#6e7681}} ul{{color:#d29922;margin:0;padding-left:20px}}
</style>
<h1>{html.escape(project.sequence_name)}</h1>
<div class="sub">{datetime.now().strftime('%Y-%m-%d %H:%M')} &middot;
{project.rate} &middot; anchor: <b>{html.escape(str(info.get('anchor') or '-'))}</b></div>
<div class="cards">
<div class="card"><b>{st['sources']}</b><span>sources</span></div>
<div class="card"><b>{st['synced']}</b><span>synced</span></div>
<div class="card"><b>{st['unsynced']}</b><span>unsynced</span></div>
<div class="card"><b>{st['multi_source_groups']}</b><span>takes</span></div>
<div class="card"><b>{fmt_tc(st['duration'], project.rate)}</b><span>duration</span></div>
<div class="card"><b>{st['missing']}</b><span>missing media</span></div>
</div>
<h2>Timeline</h2>{_bar(project)}
<h2>Takes</h2><table><tr><th>#</th><th>Sources</th><th>Start</th><th>Span</th>
<th>Conf</th><th>Recorded</th><th>Devices</th></tr>{''.join(group_rows)}</table>
<h2>Sources</h2><table><tr><th>File</th><th>Device</th><th>Type</th><th>Length</th>
<th>Take</th><th>Offset</th><th>Conf</th><th>Created</th><th>Flags</th></tr>
{''.join(src_rows)}</table>
<h2>Pairwise matches (worst residual first)</h2><table>
<tr><th>A</th><th>B</th><th>Offset</th><th>Conf</th><th>NCC</th><th>Residual</th><th></th></tr>
{''.join(edge_rows)}</table>
<h2>Warnings</h2><ul>{warn_html}</ul>
"""


def write_json(project: Project, info: dict, path: str) -> None:
    data = {
        "sequence": project.sequence_name,
        "rate": {"timebase": project.rate.timebase, "ntsc": bool(project.rate.ntsc),
                 "fps": project.rate.fps},
        "anchor": info.get("anchor"),
        "stats": project.stats(),
        "groups": [
            {"index": g.index, "timeline_start": round(g.timeline_start, 6),
             "span": round(g.span, 3), "confidence": round(g.confidence, 3),
             "recorded": g.start_time.isoformat() if g.start_time else None,
             "sources": [project.sources[n].name for n in g.source_ids]}
            for g in sorted(project.groups, key=lambda g: g.timeline_start)],
        "sources": [
            {"name": s.name, "path": s.path, "device": s.device, "kind": s.kind,
             "duration": round(s.duration, 3), "group": s.group,
             "offset": None if s.offset is None else round(s.offset, 6),
             "confidence": round(s.confidence, 3), "drift_ppm": round(s.drift_ppm, 1),
             "created": s.created_start.isoformat() if s.created_start else None,
             "created_source": s.created_at_source, "missing": bool(s.missing),
             "silent": bool(s.silent)}
            for s in project.sources.values()],
        "edges": [
            {"a": project.sources[e.a].name, "b": project.sources[e.b].name,
             "offset": round(e.offset, 6), "confidence": round(e.confidence, 3),
             "residual": round(e.residual, 6), "rejected": bool(e.rejected),
             "drift_ppm": round(e.drift_ppm, 1)}
            for e in project.edges],
        "warnings": project.warnings,
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
