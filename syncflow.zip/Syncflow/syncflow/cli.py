"""Command line entry point. All real work lives in ``pipeline``.

    syncflow project.xml -o synced.xml
    syncflow /path/to/footage --report
"""

from __future__ import annotations

import argparse
import os
import sys
import time

from .media import have_ffmpeg
from .model import fmt_tc
from .pipeline import Cancelled, Options, run


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="syncflow",
        description="Automatic multicam audio sync. XML in, synced XML out.")
    p.add_argument("input", help="FCP7 XML, FCPXML, or a folder of media")
    p.add_argument("-o", "--output", help="output XML path")
    p.add_argument("-f", "--format", choices=["xmeml", "fcpxml", "auto"],
                   default="auto", help="output flavour (default: match input)")

    g = p.add_argument_group("sync")
    g.add_argument("--min-confidence", type=float, default=0.25,
                   help="reject matches below this score (0-1, default 0.25)")
    g.add_argument("--channel", choices=["mix", "first", "left", "right"],
                   default="mix",
                   help="which source channel to analyse; use 'first' when a "
                        "stereo pair is out of phase or holds two different mics")
    g.add_argument("--no-refine", action="store_true",
                   help="skip GCC-PHAT refinement (faster, ~16 ms accuracy)")
    g.add_argument("--drift", action="store_true",
                   help="estimate clock drift between long recordings")
    g.add_argument("--residual-tol", type=float, default=0.08,
                   help="seconds of disagreement before an edge is flagged")

    g = p.add_argument_group("layout")
    g.add_argument("--order", choices=["chronological", "timestamp", "stack", "keep"],
                   default="chronological",
                   help="how takes are placed on the output timeline")
    g.add_argument("--gap", type=float, default=2.0,
                   help="seconds between takes (default 2)")
    g.add_argument("--anchor", help="device to use as the reference track "
                                    "(default: the video device with most footage)")
    g.add_argument("--mute-camera-audio", action="store_true",
                   help="drop camera scratch audio where a recorder covers the take")
    g.add_argument("--trim-head", type=float, default=0.0)
    g.add_argument("--trim-tail", type=float, default=0.0)
    g.add_argument("--min-clip", type=float, default=0.0,
                   help="drop clips shorter than this many seconds")
    g.add_argument("--fps", type=float, help="force the output sequence frame rate")

    g = p.add_argument_group("output")
    g.add_argument("--report", nargs="?", const="auto",
                   help="write an HTML review report")
    g.add_argument("--json", dest="json_out", nargs="?", const="auto",
                   help="write machine-readable results")
    g.add_argument("--multicam", action="store_true",
                   help="FCPXML only: emit real multicam clips")
    g.add_argument("--audio-layout", choices=["stereo", "split"], default="stereo",
                   help="XMEML only: one stereo track per source, or two monos")
    g.add_argument("--time-precision", choices=["frame", "sample"], default="frame",
                   help="FCPXML only: sample keeps sub-frame accuracy")
    g.add_argument("--no-markers", action="store_true")
    g.add_argument("--no-labels", action="store_true")

    g = p.add_argument_group("misc")
    g.add_argument("--media-root", action="append", default=[],
                   help="folder to search when relinking moved media (repeatable)")
    g.add_argument("--workers", type=int, default=0)
    g.add_argument("--no-cache", action="store_true")
    g.add_argument("--cache-dir")
    g.add_argument("--dry-run", action="store_true",
                   help="analyse and report, write no XML")
    g.add_argument("--gui", action="store_true",
                   help="launch the desktop interface in a browser")
    g.add_argument("-q", "--quiet", action="store_true")
    return p


def main(argv=None) -> int:
    if argv is None:
        argv = sys.argv[1:]
    if "--gui" in argv or not argv:
        from .webui import main as gui_main
        return gui_main()

    args = build_parser().parse_args(argv)
    t0 = time.time()

    def say(msg=""):
        if not args.quiet:
            print(msg, file=sys.stderr, flush=True)

    if not have_ffmpeg():
        say("error: ffmpeg and ffprobe must be on PATH")
        return 2

    opts = Options(
        input=args.input, output=args.output, format=args.format,
        min_confidence=args.min_confidence, channel=args.channel,
        refine=not args.no_refine, drift=args.drift,
        residual_tol=args.residual_tol, order=args.order, gap=args.gap,
        anchor=args.anchor, mute_camera_audio=args.mute_camera_audio,
        trim_head=args.trim_head, trim_tail=args.trim_tail,
        min_clip=args.min_clip, fps=args.fps, report=args.report,
        json_out=args.json_out, multicam=args.multicam,
        audio_layout=args.audio_layout, time_precision=args.time_precision,
        markers=not args.no_markers, labels=not args.no_labels,
        media_roots=args.media_root, workers=args.workers,
        cache=not args.no_cache, cache_dir=args.cache_dir, dry_run=args.dry_run)

    last = [0.0]

    def progress(frac, msg):
        now = time.time()
        if not args.quiet and (now - last[0] > 0.2 or frac >= 1.0):
            last[0] = now
            print(f"\r  {msg:<44} {frac*100:5.1f}%", end="", file=sys.stderr,
                  flush=True)

    try:
        res = run(opts, log=say, progress=progress)
    except Cancelled:
        say("\ncancelled")
        return 130
    except (FileNotFoundError, ValueError, RuntimeError) as exc:
        say(f"\nerror: {exc}")
        return 1

    if not args.quiet:
        print(file=sys.stderr)
    say(f"  anchor track: {res.info['anchor']}")
    say(f"  timeline: {fmt_tc(res.project.duration, res.project.rate)} "
        f"@ {res.project.rate}")
    for w in res.warnings:
        say(f"  ! {w}")
    for kind, path in res.outputs.items():
        say(f"  {kind:<6} -> {path}")
    say(f"done in {time.time()-t0:.1f}s"
        + (" (dry run, no XML written)" if args.dry_run else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
