"""Syncflow - automatic multicam audio/video synchronisation."""
__version__ = "1.0.0"
