"""Media I/O: probing, decoding and creation-time extraction, all via ffmpeg.

Decoded analysis audio and the derived feature envelopes are cached on disk
keyed by (path, size, mtime, params) so that re-running a sync on the same
footage is close to instant.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import shutil
from datetime import datetime, timezone
from typing import Optional

import numpy as np

from .model import Rate, Source


def _bootstrap_path() -> None:
    """Make ffmpeg findable when we are not running from a shell.

    An app launched from Finder or the Dock inherits a bare PATH that does not
    include Homebrew, so a perfectly good `brew install ffmpeg` is invisible.
    A frozen bundle also carries its own copy next to the executable. Both
    cases are handled here, before anything tries to resolve the binaries.
    """
    extra = []
    base = getattr(sys, "_MEIPASS", None)          # PyInstaller bundle root
    if base:
        extra += [os.path.join(base, "bin"), base]
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        extra += [exe_dir, os.path.join(os.path.dirname(exe_dir), "Resources", "bin")]
    extra += ["/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin", "/usr/bin"]

    current = os.environ.get("PATH", "").split(os.pathsep)
    for d in extra:
        if d and os.path.isdir(d) and d not in current:
            current.insert(0, d)
    os.environ["PATH"] = os.pathsep.join(current)


_bootstrap_path()

FFMPEG = shutil.which("ffmpeg") or "ffmpeg"
FFPROBE = shutil.which("ffprobe") or "ffprobe"

ANALYSIS_SR = 8000          # mono sample rate used for all correlation work
DEFAULT_CACHE = os.path.join(
    os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "syncflow"
)


def have_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


# --------------------------------------------------------------------------
# Cache
# --------------------------------------------------------------------------

class Cache:
    def __init__(self, root: str = DEFAULT_CACHE, enabled: bool = True):
        self.root = root
        self.enabled = enabled
        if enabled:
            os.makedirs(root, exist_ok=True)

    def key(self, path: str, tag: str) -> str:
        try:
            st = os.stat(path)
            sig = f"{os.path.abspath(path)}|{st.st_size}|{int(st.st_mtime)}|{tag}"
        except OSError:
            sig = f"{os.path.abspath(path)}|missing|{tag}"
        return hashlib.sha1(sig.encode("utf-8")).hexdigest()

    def _p(self, key: str, ext: str) -> str:
        return os.path.join(self.root, key[:2], key + ext)

    def get_npy(self, key: str) -> Optional[np.ndarray]:
        if not self.enabled:
            return None
        p = self._p(key, ".npy")
        if os.path.exists(p):
            try:
                return np.load(p, allow_pickle=False)
            except Exception:
                return None
        return None

    def put_npy(self, key: str, arr: np.ndarray) -> None:
        if not self.enabled:
            return
        p = self._p(key, ".npy")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "wb") as fh:      # np.save() would append another .npy
            np.save(fh, arr)
        os.replace(tmp, p)

    def get_json(self, key: str) -> Optional[dict]:
        if not self.enabled:
            return None
        p = self._p(key, ".json")
        if os.path.exists(p):
            try:
                with open(p) as fh:
                    return json.load(fh)
            except Exception:
                return None
        return None

    def put_json(self, key: str, obj: dict) -> None:
        if not self.enabled:
            return
        p = self._p(key, ".json")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(obj, fh)
        os.replace(tmp, p)


# --------------------------------------------------------------------------
# Probing
# --------------------------------------------------------------------------

def ffprobe(path: str) -> dict:
    cmd = [FFPROBE, "-v", "quiet", "-print_format", "json",
           "-show_format", "-show_streams", path]
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if out.returncode != 0 or not out.stdout.strip():
        raise RuntimeError(f"ffprobe failed for {path}: {out.stderr[:400]}")
    return json.loads(out.stdout)


_TC_RE = re.compile(r"^(\d+):(\d+):(\d+)[:;](\d+)$")


def _parse_tc(tc: str, fps: float) -> Optional[float]:
    m = _TC_RE.match(tc.strip())
    if not m or not fps:
        return None
    h, mnt, s, f = (int(x) for x in m.groups())
    return h * 3600 + mnt * 60 + s + f / fps


def _parse_dt(value: str) -> Optional[datetime]:
    if not value:
        return None
    v = value.strip().replace("Z", "+00:00")
    # EXIF style "2024:05:17 14:30:22"
    m = re.match(r"^(\d{4}):(\d{2}):(\d{2})[ T](\d{2}):(\d{2}):(\d{2})", v)
    if m:
        v = "{}-{}-{}T{}:{}:{}".format(*m.groups()) + v[19:]
    try:
        dt = datetime.fromisoformat(v)
    except ValueError:
        for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z",
                    "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S"):
            try:
                dt = datetime.strptime(v, fmt)
                break
            except ValueError:
                continue
        else:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


# Filenames that carry a wall-clock stamp, most-specific first.
_NAME_DT_PATTERNS = [
    (re.compile(r"(20\d{2})[-_]?(\d{2})[-_]?(\d{2})[-_ T]?(\d{2})[-_:]?(\d{2})[-_:]?(\d{2})"), 6),
    (re.compile(r"(\d{2})(\d{2})(\d{2})[-_](\d{2})(\d{2})(\d{2})"), 6),  # YYMMDD_HHMMSS
]


def _dt_from_name(name: str) -> Optional[datetime]:
    for pat, n in _NAME_DT_PATTERNS:
        m = pat.search(name)
        if not m:
            continue
        g = [int(x) for x in m.groups()]
        if n == 6:
            y = g[0] if g[0] > 100 else 2000 + g[0]
            try:
                return datetime(y, g[1], g[2], g[3], g[4], g[5], tzinfo=timezone.utc)
            except ValueError:
                continue
    return None


_CREATION_TAGS = [
    ("com.apple.quicktime.creationdate", "quicktime"),
    ("creation_time", "container"),
    ("date", "container"),
    ("DateTimeOriginal", "exif"),
    ("date_recorded", "container"),
]


def probe_source(path: str, sid: str, name: str = "") -> Source:
    """Build a Source from a file on disk."""
    src = Source(id=sid, path=path, name=name or os.path.basename(path))
    if not os.path.exists(path):
        src.missing = True
        return src

    info = ffprobe(path)
    fmt = info.get("format", {})
    streams = info.get("streams", [])

    try:
        src.duration = float(fmt.get("duration") or 0.0)
    except (TypeError, ValueError):
        src.duration = 0.0

    vstream = next((s for s in streams if s.get("codec_type") == "video"
                    and s.get("disposition", {}).get("attached_pic", 0) == 0), None)
    astream = next((s for s in streams if s.get("codec_type") == "audio"), None)
    dstream = next((s for s in streams if s.get("codec_type") == "data"
                    and "timecode" in json.dumps(s.get("tags", {})).lower()), None)

    if vstream is not None:
        src.has_video = True
        src.width = int(vstream.get("width") or 0)
        src.height = int(vstream.get("height") or 0)
        rfr = vstream.get("avg_frame_rate") or vstream.get("r_frame_rate") or "0/0"
        try:
            n, d = rfr.split("/")
            fps = float(n) / float(d) if float(d) else 0.0
        except (ValueError, ZeroDivisionError):
            fps = 0.0
        if fps > 0:
            src.rate = Rate.from_fps(fps)
        sar = vstream.get("sample_aspect_ratio") or "1:1"
        try:
            n, d = sar.split(":")
            src.par = float(n) / float(d) if float(d) else 1.0
        except (ValueError, ZeroDivisionError):
            src.par = 1.0
        if not src.duration:
            try:
                src.duration = float(vstream.get("duration") or 0.0)
            except (TypeError, ValueError):
                pass

    if astream is not None:
        src.has_audio = True
        src.audio_channels = int(astream.get("channels") or 0)
        try:
            src.audio_rate = int(astream.get("sample_rate") or 48000)
        except (TypeError, ValueError):
            src.audio_rate = 48000
        if not src.duration:
            try:
                src.duration = float(astream.get("duration") or 0.0)
            except (TypeError, ValueError):
                pass

    # ---- embedded start timecode ------------------------------------
    tags = {}
    tags.update(fmt.get("tags", {}) or {})
    for s in streams:
        tags.update(s.get("tags", {}) or {})
    if dstream:
        tags.update(dstream.get("tags", {}) or {})
    tc = tags.get("timecode") or tags.get("TIMECODE")
    if tc:
        src.start_timecode = _parse_tc(tc, src.rate.fps or 25.0)

    # ---- reel / camera identity -------------------------------------
    for k in ("reel_name", "com.apple.proapps.reel", "reel",
              "com.apple.quicktime.model", "model"):
        if tags.get(k):
            src.reel = str(tags[k])[:64]
            break

    # ---- creation time ----------------------------------------------
    for tag, origin in _CREATION_TAGS:
        for key in (tag, tag.lower(), tag.upper()):
            if key in tags:
                dt = _parse_dt(str(tags[key]))
                if dt:
                    src.created_at = dt
                    src.created_at_source = origin
                    src.created_at_kind = "unknown"
                    break
        if src.created_at:
            break

    if src.created_at is None:
        dt = _dt_from_name(src.name)
        if dt:
            src.created_at, src.created_at_source = dt, "filename"
            src.created_at_kind = "start"

    if src.created_at is None:
        try:
            st = os.stat(path)
            src.created_at = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
            src.created_at_source = "mtime"
            src.created_at_kind = "end"   # mtime is usually when writing finished
        except OSError:
            pass

    return src


# --------------------------------------------------------------------------
# Audio decoding
# --------------------------------------------------------------------------

def decode_audio(path: str, sr: int = ANALYSIS_SR, channel_mode: str = "mix",
                 stream: int = 0, cache: Optional[Cache] = None) -> np.ndarray:
    """Decode a file's audio to mono float32 at ``sr``.

    channel_mode:
      mix    - downmix every channel (default, best general case)
      first  - use channel 1 only (use when a recorder has a mic on ch1 and a
               line feed on ch2, or when channels are out of phase and the
               downmix cancels itself out)
      left/right - explicit channel picks
    """
    tag = f"pcm|{sr}|{channel_mode}|{stream}"
    key = cache.key(path, tag) if cache else None
    if cache:
        got = cache.get_npy(key)
        if got is not None:
            return got

    if channel_mode == "first" or channel_mode == "left":
        af = "pan=mono|c0=c0"
    elif channel_mode == "right":
        af = "pan=mono|c0=c1"
    else:
        af = "aformat=channel_layouts=mono"

    cmd = [FFMPEG, "-v", "error", "-nostdin", "-i", path,
           "-map", f"0:a:{stream}?", "-vn", "-sn", "-dn",
           "-af", af, "-ar", str(sr), "-ac", "1",
           "-f", "f32le", "-acodec", "pcm_f32le", "-"]
    proc = subprocess.run(cmd, capture_output=True)
    if proc.returncode != 0:
        raise RuntimeError(f"audio decode failed for {path}: "
                           f"{proc.stderr.decode('utf-8', 'replace')[:300]}")
    audio = np.frombuffer(proc.stdout, dtype=np.float32).copy()
    audio = np.nan_to_num(audio, copy=False)
    if cache and key:
        cache.put_npy(key, audio)
    return audio


def is_silent(audio: np.ndarray, threshold_db: float = -60.0) -> bool:
    if audio.size == 0:
        return True
    rms = float(np.sqrt(np.mean(np.square(audio, dtype=np.float64))))
    if rms <= 0:
        return True
    return bool(20 * np.log10(rms) < threshold_db)
